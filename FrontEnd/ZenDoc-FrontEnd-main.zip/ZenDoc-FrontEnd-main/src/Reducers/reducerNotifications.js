import {
    LOAD_DATA,
    FETCH_DETAILS,
    FILTER_BY_DATE,
    FILTER_BY_FUTURE_DATE
  } from "../Actions/notifications";
  

const initState = {
  appointmentDetail: [],
  filteredAppointments: []
};

const allAppointmentDetaails = {
  filteredAppointments: [],
  appointmentDetail: [
    {
      id: 1,
      name: "Mr. Williams",
      imgUrl: "https://picsum.photos/50/50?random=1",
      contact: "+910123456789",
      date_time: "07/03/2021 - 2:30pm",
      day: "today"
    },
    {
      id: 2,
      name: "Mr. Williams",
      imgUrl: "https://picsum.photos/50/50?random=1",
      contact: "+910123456789",
      date_time: "07/03/2021 - 2:30pm",
      day: "today"
    },
    {
      id: 3,
      name: "Mr. Williams",
      imgUrl: "https://picsum.photos/50/50?random=1",
      contact: "+910123456789",
      date_time: "06/28/2021 - 2:30pm",
      day: "today"
    },
    {
      id: 4,
      name: "Mr. Williams",
      imgUrl: "https://picsum.photos/50/50?random=1",
      contact: "+910123456789",
      date_time: "06/10/2020 - 2:30pm",
      day: "not-today"
    },
    {
      id: 5,
      name: "Mr. Williams",
      imgUrl: "https://picsum.photos/50/50?random=1",
      contact: "+910123456789",
      date_time: "06/10/2020 - 2:30pm",
      day: "not-today"
    }
  ]
};

const appointmentDetails = (state = initState, action) => {
  switch (action.type) {
    case "LOAD_DATA":
      return {
        ...state,
        appointmentDetails:action.payload
      }

    case "FILTER_BY_DATE":
      
    case "FILTER_BY_FUTURE_DATE":
      return {
        ...state,
        filteredAppointments: action.payload.filteredAppointments
      };

    default:
      return initState;
  }
};

export default appointmentDetails;

  