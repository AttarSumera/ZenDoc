import {
    ADD_NEW_PATIENT, PATIENT_DETAILS, WRITE_DOCTOR_NOTE, WRITE_PSYCHO_NOTE,
    GET_DOCTOR_NOTES, GET_PSYCHO_NOTES, GET_PATIENTS_LIST, SET_SELECTED_PATIENT, PATIENT_CREATED
} from '../Actions/type.js';

const initialState = {
    addNewPatient: false,
    searchText: '',
    patientsList: null,
    psychoNote: false,
    doctorNote: false,
    psychoNoteDetail: null,
    doctorNoteDetail: null,
    patientInfo: null,
};

export default function (state = initialState, action) {
    switch (action.type) {
        case PATIENT_DETAILS:
            return action.payload;
        case ADD_NEW_PATIENT:
            return { ...state, ...action.payload };
        case WRITE_PSYCHO_NOTE:
            return { ...state, psychoNote: action.payload }
        case WRITE_DOCTOR_NOTE:
            return { ...state, doctorNote: action.payload }
        case GET_DOCTOR_NOTES:
            return { ...state, ...action.payload }
        case GET_PSYCHO_NOTES:
            return { ...state, ...action.payload }
        case GET_PATIENTS_LIST:
            return {
                ...state,
                patientsList: action.payload.patientList,
                searchText: action.payload.searchText
            };
        case SET_SELECTED_PATIENT:
            return {
                ...state,
                patientInfo: state.patientsList.find(patient => patient.patientid = action.payload),
                searchText: '',
                patientList: null
            }
        case PATIENT_CREATED:
            return {
                ...state,
                patientInfo: action.payload,
                addNewPatient: false
            }
        default:
            return state;
    }
}