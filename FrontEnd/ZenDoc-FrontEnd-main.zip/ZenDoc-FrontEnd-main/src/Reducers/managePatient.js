import { GET_MANAGE_PATIENTS,GET_PATIENT_HISTORY,SET_SELECTED_TAB
,SET_SELECTED_NOTE } from "../Actions/type";

const initialState = {
    /*patientInfo:{
        notes:[
            {
                name:'test'
            }
        ]
    }*/
    //patientsList:[
    //     {
    //         userName:'Ajay Yadav',
    //         country:'India',
    //         mobile:'9650097870',
    //         image:''
    //     },{
    //         userName:'Ajay Yadav',
    //         country:'India',
    //         mobile:'9650097870',
    //         image:''
    //     }
    // ]
};

const managePatient = (state = initialState,action) => {
    switch(action.type) {
        case GET_MANAGE_PATIENTS:
            return { ...state,patientsList:action.payload };
        case GET_PATIENT_HISTORY:
            return { ...state,
                patientsList:null,
                patientHistory:action.payload.patientHistory,
                patientInfo:action.payload.patientInfo,
                selectedTabID:1
            }
        case SET_SELECTED_TAB:
            return { ...state, selectedTabID:action.payload }
        case SET_SELECTED_NOTE:
            return { ...state, selectedNoteID:action.payload }
        default:
            return state;
    }
}

export default managePatient;