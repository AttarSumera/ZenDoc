import { ADD_NEW_SCHEDULE,GET_SCHEDULES,SAVE_SCHEDULE } from "../Actions/type";

const initialState = {
    addNewSchedule:false
}

export default function(state=initialState,action) {
    switch(action.type) {
        case ADD_NEW_SCHEDULE:
            return {
                ...state, 
                addNewSchedule:action.payload
            }
        case SAVE_SCHEDULE:
            return {
                ...state,
                addNewSchedule:false,
                meetingList:[...state.meetingList,...action.payload]
            }
        case GET_SCHEDULES:
            return {
                ...state,
                meetingList:action.payload
            }
        default:
            return state;
    }
}