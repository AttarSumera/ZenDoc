import axios from 'axios';
import { getUserIDFromIndexedDB, storeDataInIndexedDB, deleteDataFromIndexedDB } from './indexedDB';

import {
    REGISTER_SUCCESS,
    REGISTER_FAIL,
    LOGIN_SUCCESS,
    LOGIN_FAIL,
    LOGOUT,
    SET_MESSAGE,
    INVALID_CREDS,
    DOCTOR_DETAILS
} from '../Actions/type';

import API from '../Services';

export const login = (userInfo, history, setErrors, setAccount, setLastname, setUserID, completeProfilePercenrtage) => {
    return async (dispatch) => {
        try {

            const response = await axios.post('http://localhost:5000/login', userInfo);

            if (response.data.data.message === "Incorrect password") {
                setErrors((prevErrors) => ({
                    ...prevErrors,
                    loginError: 'Incorrect password'
                }));
            }
            else {
                await storeDataInIndexedDB('Token', response.data.data.sessionToken);
                await storeDataInIndexedDB('UserId', response.data.data.userId);

                const UserId = await getUserIDFromIndexedDB();

                const UserDetails = await API.post("user/userDetails", {
                    username: userInfo.username
                });

                if (UserDetails) {
                    const doctorDetails = UserDetails.data;
                    setAccount(doctorDetails.firstName)
                    setLastname(doctorDetails.lastName)
                    dispatch({
                        type: DOCTOR_DETAILS,
                        payload: doctorDetails
                    });
                } else {
                    console.log("Data Not Found in userDetails  API")
                }

                if (completeProfilePercenrtage == 100.00) {
                    history.push('/dashboard');
                } else {
                    history.push('/Onboard');
                }

                dispatch({
                    type: LOGIN_SUCCESS,
                    payload: UserId
                });
            }

        } catch (error) {
            console.log(error);
            setErrors((prevErrors) => ({
                ...prevErrors,
                loginError: 'An error occurred'
            }));
            dispatch({
                type: LOGIN_FAIL,
                payload: { message: 'An error occurred' }
            });
        }
    }
}

export const createDoctor = (userInfo, history, setErrors) => {
    return async (dispatch) => {
        try {
            const response = await API.post('user/createDoctor', userInfo);

            console.log("Response:", response);

            if (response && response.data && response.data.code.toLowerCase() === "success") {
                dispatch({
                    type: REGISTER_SUCCESS,
                    payload: userInfo
                });
                history.push('/');
            } else {
                setErrors(prevErrors => ({
                    ...prevErrors,
                    signupError: "User Already Exists, Please Login To Continue"
                }));
            }
        } catch (error) {
            console.error("Error during signup:", error);
            setErrors(prevErrors => ({
                ...prevErrors,
                signupError: "User Already Exists, Please Login To Continue"
            }));
        }
    };
};


export const invalidCreds = (msg) => {
    return {
        type: INVALID_CREDS,
        payload: msg
    }
}

export const Logout = async (history) => {
    try {
        await deleteDataFromIndexedDB('Token');
        await deleteDataFromIndexedDB('UserId');
        console.log("Token & UserId Removed from IndexedDB");
    } catch (error) {
        console.error("Error removing data from IndexedDB:", error);
    }
    history.push('/');
    console.log("Token & UserId Removed")
}