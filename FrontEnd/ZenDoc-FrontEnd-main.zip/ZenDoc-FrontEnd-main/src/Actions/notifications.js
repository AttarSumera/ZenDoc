const FETCH_DETAILS = "FETCH_DETAILS";
const FILTER_BY_DATE = "FILTER_BY_DATE";
const FILTER_BY_FUTURE_DATE = "FILTER_BY_FUTURE_DATE";
const LOAD_DATA = "LOAD_DATA";

import API from '../Services';

export const loadData = (userInfo) => {
  return async (dispatch,getState) => {
      const response = await API.post('schedule/getScheduleDetail',userInfo);

      if(response.data.code.toLowerCase() == 'success') {
        dispatch({
            type:LOAD_DATA,
            payload:response.data.data
        });
      }
  }
};

export const filterByDate = (appointmentDetails, date) => {
  return {
    type: FILTER_BY_DATE,
    payload: {
      date: date,
      filteredAppointments: appointmentDetails.filter(
        (details) => details.day === date
      )
    }
  };
};

export const filterByFutureDate = (appointmentDetails, date) => {
  return {
    type: FILTER_BY_FUTURE_DATE,
    payload: {
      date: date,
      filteredAppointments: appointmentDetails.filter(
        (details) => details.day === date
      )
    }
  };
};
