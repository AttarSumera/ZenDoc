import { GET_MANAGE_PATIENTS } from "./type";
import { GET_PATIENT_HISTORY } from "./type";
import { SET_SELECTED_TAB } from "./type";
import { SET_SELECTED_NOTE } from "./type";

import API from "../Services";

export const getPatientsToManage = (searchString) => {
  return async (dispatch, getState) => {
    // const response = await API.post("/user/searchPatient", {
    //   SearchId: searchString,
    //   NumOfRecords: 2,
    // });
    dispatch({
      type: GET_MANAGE_PATIENTS,
      payload: [
        {
          id: 1,
          firstName: "David",
          lastName: "X",
          middleName: "James",
          Age: "23",
          sex: "male",
          consulting: "Virtual Consulting",
        },
        {
          id: 2,
          firstName: "Tony",
          lastName: "v",
          middleName: "Stark",
        },
        {
          id: 3,
          firstName: "Bessie",
          lastName: "X",
          middleName: "Berry",
        },
      ],
    });
    // dispatch({
    //     type:GET_MANAGE_PATIENTS,
    //     payload:response.data.data
    // })
  };
};

export const setSelectedTab = (tabID) => {
  return {
    type: SET_SELECTED_TAB,
    payload: tabID,
  };
};

export const setSelectedNoteID = (noteID) => {
  return {
    type: SET_SELECTED_NOTE,
    payload: noteID,
  };
};

export const getPatientHistory = (info, patientInfo) => {
  // return async (dispatch,getState) => {
  //     const response = await API.post('/prescriptionDetails/getPatientHistory',info);
  // }
  const response = {
    code: "SUCCESS",
    data: {
      doctorNotes: [
        {
          Date: "2021-09-05 01:07:15.000000",
          docNoteID: 2,
          illnessType: 1,
          illnessDurationUnit: 2,
          illnessDurationNumber: 10,
          patChiefComplaints: "The patient complains of abdominal pain.",
          relevantHistory:
            "The patient has intermittent, sharp pain in the right upper quadrant without associated nausea, vomiting, or diarrhea.",
          pastHistory:
            "Diabetes controlled by oral medication; extrinsic asthma without acute exacerbation in past six months.",
          personaTemperTraits:
            "Hypertension stable with pressures ranging from 130-140/80-90.",
          provisionalDiagnosis:
            "Initial hospital care, inpatient consultations, and initial observation care.",
          physicalExam_BP: "140/90",
          physicalExam_pulse: 80,
          physicalExam_height: 180,
          physicalExam_weight: 78,
          sessionNumber: 2,
          createdAt: "2021-08-14T14:21:50.000Z",
          updatedAt: "2021-08-14T14:21:50.000Z",
          MSE_ID: 5,
          MSE_GAB: "Disheveled appearance may suggest schizophrenia.",
          MSE_PMA:
            "Excessive motor activity may include pacing, wringing of hands, inability to sit still.",
          MSE_speech_quantity: "Talkative",
          MSE_speech_rate: 2,
          MSE_speech_tone: "Monotone",
          MSE_speech_volume: "Mumbled",
          MSE_speech_reactionTime: "Slow",
          MSE_mood_affect:
            "Depression, bipolar disorder, anxiety, schizophrenia.",
          MSE_thought_possession:
            "Anxiety, depression, schizophrenia, dementia, delirium, substance abuse.",
          MSE_thought_content: "Suicidal or homicidal thoughts.",
          MSE_perception: "Acute intoxication and withdrawal.",
          MSE_HMFCogn: "Underlying medical conditions, dementia, delirium.",
        },
        {
          Date: "2021-09-05 01:07:15.000000",
          docNoteID: 1,
          illnessType: 1,
          illnessDurationUnit: 2,
          illnessDurationNumber: 10,
          patChiefComplaints: "The patient complains of abdominal pain.",
          relevantHistory:
            "The patient has intermittent, sharp pain in the right upper quadrant without associated nausea, vomiting, or diarrhea.",
          pastHistory:
            "Diabetes controlled by oral medication; extrinsic asthma without acute exacerbation in past six months.",
          personaTemperTraits:
            "Hypertension stable with pressures ranging from 130-140/80-90.",
          provisionalDiagnosis:
            "Initial hospital care, inpatient consultations, and initial observation care.",
          physicalExam_BP: "140/90",
          physicalExam_pulse: 80,
          physicalExam_height: 180,
          physicalExam_weight: 78,
          sessionNumber: 2,
          createdAt: "2021-08-14T14:21:50.000Z",
          updatedAt: "2021-08-14T14:21:50.000Z",
          MSE_ID: 5,
          MSE_GAB: "Disheveled appearance may suggest schizophrenia.",
          MSE_PMA:
            "Excessive motor activity may include pacing, wringing of hands, inability to sit still.",
          MSE_speech_quantity: "Talkative",
          MSE_speech_rate: 2,
          MSE_speech_tone: "Monotone",
          MSE_speech_volume: "Mumbled",
          MSE_speech_reactionTime: "Slow",
          MSE_mood_affect:
            "Depression, bipolar disorder, anxiety, schizophrenia.",
          MSE_thought_possession:
            "Anxiety, depression, schizophrenia, dementia, delirium, substance abuse.",
          MSE_thought_content: "Suicidal or homicidal thoughts.",
          MSE_perception: "Acute intoxication and withdrawal.",
          MSE_HMFCogn: "Underlying medical conditions, dementia, delirium.",
        },
      ],
      drugs: [
        {
          Date: "2021-09-05 01:07:15.000000",
          dosage: 100,
          drugID: 420,
          drugName: "dolemite",
          isActive: 1,
          afterFood: 1,
          createdAt: "2021-09-05 01:13:01.000000",
          updatedAt: "2021-09-05 01:14:07.000000",
          durationUnit: 1,
          recordedVoice: "URL",
          durationNumber: 2,
          medicineAdvice: "Take for depression and anxiety.",
          repetitionUnit: 1,
          drugPrescriptionID: 1,
        },
        {
          Date: "2021-09-05 01:07:15.000000",
          dosage: 100,
          drugID: 543,
          drugName: "paracetamol",
          isActive: 1,
          afterFood: 1,
          createdAt: "2021-09-05 01:14:07.000000",
          updatedAt: "2021-09-05 01:14:07.000000",
          durationUnit: 1,
          recordedVoice: "URL",
          durationNumber: 2,
          medicineAdvice: "Take only after 6 hours gap.",
          repetitionUnit: 1,
          drugPrescriptionID: 1,
        },
      ],
      tools: [
        {
          toolId: 1,
          doctorID: "_aslsasa",
          isActive: 1,
          createdAt: "2021-09-05 01:11:24.000000",
          patientID: "_asllskk",
          toolPatId: 1,
          updatedAt: "2021-09-05 01:14:07.000000",
          durationUnit: 1,
          taskGoalName: "Task 1",
          recordedVoice: "URL",
          durationNumber: 2,
          sessionNumbers: "1,2",
          supportContact: "+91-9560280973",
          motivationalMessage: "This will help you!",
        },
        {
          toolId: 2,
          doctorID: "_aslsasa",
          isActive: 1,
          createdAt: "2021-09-05 01:11:24.000000",
          patientID: "_asllskk",
          toolPatId: 2,
          updatedAt: "2021-09-05 01:14:07.000000",
          durationUnit: 1,
          taskGoalName: "Task 2",
          recordedVoice: "URL",
          durationNumber: 2,
          sessionNumbers: "1,2,3",
          supportContact: "+91-9560280973",
          motivationalMessage: "This will strengthen you!",
        },
      ],
    },
  };
  const patientObj = {
    patientHistory: response.data,
    patientInfo: patientInfo,
  };
  return {
    type: GET_PATIENT_HISTORY,
    payload: patientObj,
  };
};
