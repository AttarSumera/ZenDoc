import { ADD_NEW_SCHEDULE, GET_SCHEDULES, SAVE_SCHEDULE } from "./type"
import API from '../Services/index';

export const addNewScheduleFlag = (toggle) => {
    return {
        type: ADD_NEW_SCHEDULE,
        payload: toggle
    }
}

export const addNewScheduleMeeting = (meetingDetails) => {
    return async (dispatch, getState) => {
        const response = await API.post('/schedule/createSchedule', meetingDetails);

        if (response)
            meetingDetails.scheduleID = response.data.scheduleId
        dispatch({
            type: SAVE_SCHEDULE,
            payload: [meetingDetails]
        })
    }
}

export const updateSchedule = (scheduleData) => ({
    type: 'UPDATE_SCHEDULE',
    payload: scheduleData,
});

// scheduleReducer.js
const initialState = {
    scheduleData: [],
};

const scheduleReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'UPDATE_SCHEDULE':
            return {
                ...state,
                scheduleData: action.payload,
            };
        default:
            return state;
    }
};

export default scheduleReducer;

export const getScheduleDetail = (userID) => {
    // return async(dispatch,getState) => {
    //     const response = await API.post('/schedule/getScheduleDetail',{
    //         userID:userID
    //     })

    //     if(response) {
    //         dispatch({
    //             type:GET_SCHEDULES,
    //             payload:response.data
    //         })
    //     }
    // }
    const response = {
        "code": "SUCCESS",
        "data": [
            {
                "scheduleID": 3,
                "userID": 1,
                "patientID": "_9elmt3wt5",
                "appointmentTitle": "Meeting with Anil for OCD",
                "scheduleDate": "2021-11-02",
                "startTime": "09:00:00",
                "endTime": "10:00:00",
                "message": "OCD with severe symptoms",
                "priority": 1,
                "problem": "OCD OCD",
                "SideAffectReported": 1,
                "isVirtualMeeting": 0,
                "inviteeEmailId": "sejwani2@gmail.com",
                "inviteeMobileNumber": "+91-9560222032",
                "isApproved": 1,
                "firstName": "Anil",
                "middleName": "Kumar",
                "lastName": "Maharia",
                "scheduleGroupType": "UpComing"
            }
        ]
    }

    return {
        type: GET_SCHEDULES,
        payload: response.data
    }
}