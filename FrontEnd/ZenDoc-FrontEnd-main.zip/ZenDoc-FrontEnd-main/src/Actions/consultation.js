import { PATIENT_DETAILS } from './type';
import { ADD_NEW_PATIENT } from './type';
import { WRITE_DOCTOR_NOTE } from './type';
import { WRITE_PSYCHO_NOTE } from './type';
import { GET_DOCTOR_NOTES } from './type';
import { GET_PSYCHO_NOTES } from './type';
import { GET_PATIENTS_LIST } from './type';
import { SET_SELECTED_PATIENT } from './type';
import { SAVE_DOCTOR_NOTE } from './type';
import { PATIENT_CREATED } from './type';

import API from '../Services';
import { getUserIDFromIndexedDB } from './indexedDB';

export const addAndLoadPatient = (patientDetail) => {
    return async (dispatch, getState) => {
        patientDetail.dob = new Date().toString();
        const response = await API.post('user/createAndLoadPatient', patientDetail);
        if (response.data.code.toLowerCase() == "success") {
            dispatch({
                type: PATIENT_CREATED,
                payload: { ...patientDetail }
            })
        }
    }
}

export const addNewPatientFlag = (addNewPatient) => {
    let returnObj = {}
    returnObj.searchText = '';
    returnObj.patientList = null;
    returnObj.addNewPatient = addNewPatient;

    return {
        type: ADD_NEW_PATIENT,
        payload: returnObj
    }
}

export const writeDoctorNote = (doctorNote) => {
    return {
        type: WRITE_DOCTOR_NOTE,
        payload: doctorNote
    }
}

export const writePsychoNote = (psychoNote) => {
    return {
        type: WRITE_PSYCHO_NOTE,
        payload: psychoNote
    }
}

export const getDoctorNoteDetails = (requestObject) => {
    return async (dispatch, getState) => {
        // return (dispatch,getState) => {
        const response = await API.post('/prescriptionDetails/getDoctorNoteDetail', {
            patID: requestObject.patID,
            userID: requestObject.userID,
            isViewLastNote: 1
        });
        // let response = {
        //     "docNoteID": 3,
        //     "illnessType": 1,
        //     "illnessDurationUnit": 2,
        //     "illnessDurationNumber": 10,
        //     "patChiefComplaints": "The patient complains of abdominal pain.",
        //     "relevantHistory": "The patient has intermittent, sharp pain in the right upper quadrant without associated nausea, vomiting, or diarrhea.",
        //     "pastHistory": "Diabetes controlled by oral medication; extrinsic asthma without acute exacerbation in past six months.",
        //     "personaTemperTraits": "Hypertension stable with pressures ranging from 130-140/80-90.",
        //     "provisionalDiagnosis": "Initial hospital care, inpatient consultations, and initial observation care.",
        //     "physicalExam_BP": "140/90",
        //     "physicalExam_pulse": 80,
        //     "physicalExam_height": 180,
        //     "physicalExam_weight": 78,
        //     "sessionNumber": 2,
        //     "createdAt": "2021-08-14T14:21:50.000Z",
        //     "updatedAt": "2021-08-14T14:21:50.000Z",
        //     "MSE_ID": 5,
        //     "MSE_GAB": "Disheveled appearance may suggest schizophrenia.",
        //     "MSE_PMA": "Excessive motor activity may include pacing, wringing of hands, inability to sit still.",
        //     "MSE_speech_quantity": "Talkative",
        //     "MSE_speech_rate": 2,
        //     "MSE_speech_tone": "Monotone",
        //     "MSE_speech_volume": "Mumbled",
        //     "MSE_speech_reactionTime": "Slow",
        //     "MSE_mood_affect": "Depression, bipolar disorder, anxiety, schizophrenia.",
        //     "MSE_thought_possession": "Anxiety, depression, schizophrenia, dementia, delirium, substance abuse.",
        //     "MSE_thought_content": "Suicidal or homicidal thoughts.",
        //     "MSE_perception": "Acute intoxication and withdrawal.",
        //     "MSE_HMFCogn": "Underlying medical conditions, dementia, delirium."
        // }
        console.log(response)
        dispatch({
            type: GET_DOCTOR_NOTES,
            payload: {
                doctorNoteDetail: response.data.data,
                doctorNote: false
            }
        })
    }
}

export const getPsychoNoteDetails = (requestObject) => {
    return async (dispatch, getState) => {
        //return async (dispatch,getState) => {
        const response = await API.post('/prescriptionDetails/getPsychotherapyNoteDetail', {
            patID: requestObject.patID,
            userID: requestObject.userID,
            isViewLastNote: 1
        });
        // let response = {

        // }

        dispatch({
            type: GET_PSYCHO_NOTES,
            payload: {
                psychoNoteDetail: response.data.data,
                psychoNote: false
            }
        })
    }
}

export const getPatientList = (searchText) => {
    if (searchText.length == 0)
        return {
            type: GET_PATIENTS_LIST,
            payload: {
                patientList: null,
                searchText
            }
        }
    // return async (dispatch, getState) => {
    return async (dispatch, getState) => {
        const userId = await getUserIDFromIndexedDB();
        try {
            const response = await API.post('/user/searchPatient', {
                UserId: userId,
                SearchId: searchText,
                NumOfRecords: 3,
            });
            // var response = [];
            // if (searchText == "sha") {
            //     response.push({
            //         firstName: 'test',
            //         lastName: 'test',
            //         dateOfBirth: "1991-10-10 00:00:00.000000",
            //         gender: 'male',
            //         emailID: 'adfdsfa',
            //         phoneNumber: '9879879898',
            //         UserId: 'afasf'
            //     })
            //     response.push({
            //         firstName: 'test',
            //         lastName: 'test',
            //         dateOfBirth: "1991-10-10 00:00:00.000000",
            //         gender: 'male',
            //         emailID: 'adfdsfa',
            //         phoneNumber: '9879879898',
            //         UserId: 'afasfasd'
            //     })
            // }

            dispatch({
                type: GET_PATIENTS_LIST,
                payload: {
                    patientList: response.data.data,
                    searchText
                }
            })
        } catch (error) {
            console.log("ERRO TO FETCH PATIENT LIST")
            dispatch({
                type: GET_PATIENTS_LIST,
                payload: {
                    patientList: [],
                    searchText
                }
            })
        }

    }
}

export const setSelectedPatient = (patientID) => {
    return {
        type: SET_SELECTED_PATIENT,
        payload: patientID
    }
}

export const saveDoctorNote = (docNote) => {
    return async (dispatch, getState) => {
        const response = await API.post('/prescriptionDetails/saveDoctorNote', docNote);
        if (response.data.code.toLowerCase() == "success")
            dispatch({
                type: GET_DOCTOR_NOTES,
                payload: {
                    doctorNoteDetail: docNote,
                    doctorNote: false
                }
            })
    }
}

export const savePsychoNote = (psychoNote) => {
    return async (dispatch, getState) => {
        const response = await API.post('/prescriptionDetails/savePsychotherapyNote', psychoNote);
        console.log(response)
        if (response.data.code.toLowerCase() == "success") {
            dispatch({
                type: GET_PSYCHO_NOTES,
                payload: {
                    psychoNoteDetail: psychoNote,
                    psychoNote: false
                }
            })
        }
    }
}