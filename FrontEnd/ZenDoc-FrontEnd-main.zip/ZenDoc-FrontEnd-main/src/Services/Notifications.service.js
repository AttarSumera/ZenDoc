import axios from 'axios';

export const loadData = () => {
  return async (dispatch, getState) => {
    try {
      const response = await axios.get('http://localhost:3001/appointments'); 
      const data = response.data;

      dispatch({
        type: LOAD_DATA,
        payload: data
      });
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
};
