// cryptoUtils.js

import CryptoJS from 'crypto-js';

// Function to generate a random encryption key
const generateEncryptionKey = () => {
  return CryptoJS.lib.WordArray.random(16).toString(CryptoJS.enc.Hex); // Generate a 128-bit (16 bytes) key
};

export const ENCRYPTION_KEY = generateEncryptionKey(); // Generate the encryption key

export const encryptData = (data) => {
  return CryptoJS.AES.encrypt(JSON.stringify(data), ENCRYPTION_KEY).toString();
};

export const decryptData = (encryptedData) => {
  const bytes = CryptoJS.AES.decrypt(encryptedData, ENCRYPTION_KEY);
  return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
};
