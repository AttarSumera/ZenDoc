import axios from 'axios';
import { getUserIDFromIndexedDB } from './IndexDB';

const API_URL = 'http://localhost:5000';

export const AddNewPatientService = async (formData) => {
    try {
        const userId = await getUserIDFromIndexedDB();

        if (!userId) {
            console.log('UserId is not stored in IndexedDB.');
            return false;
        }

        const requestData = {
            patientName: formData.patientName,
            sex: formData.sex,
            emailAddress: formData.emailAddress,
            mobileNumber: formData.mobileNumber,
            doctorId: userId,
            dob: "1992-07-22"
        };

        const response = await axios.post(`${API_URL}/v1/user/createAndLoadPatient`, requestData);

        if (response.status === 200) {
            console.log('Data successfully submitted!');
            console.log(userId);
            console.log(response);
            return true;
        } else {
            console.error('Failed to submit data.');
            return false;
        }
    } catch (error) {
        console.error('Error during data submission:', error);
        return false;
    }
};
