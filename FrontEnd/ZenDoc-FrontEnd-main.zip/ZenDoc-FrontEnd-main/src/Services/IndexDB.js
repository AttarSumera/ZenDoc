export const storeDataInIndexedDB = async (key, value) => {
    return new Promise((resolve, reject) => {
        const request = window.indexedDB.open('myDatabase', 1);

        request.onerror = (event) => {
            console.error('Failed to open IndexedDB:', event.target.error);
            reject(event.target.error);
        };

        request.onsuccess = (event) => {
            const db = event.target.result;
            const transaction = db.transaction(['userData'], 'readwrite');
            const objectStore = transaction.objectStore('userData');

            const getRequest = objectStore.get(key);

            getRequest.onsuccess = (event) => {
                const existingData = event.target.result;
                if (existingData) {
                    console.log('Key already exists in IndexedDB. Updating data.');
                    existingData.value = value;
                    const updateRequest = objectStore.put(existingData);
                    updateRequest.onsuccess = () => {
                        console.log('Data successfully updated in IndexedDB');
                        resolve();
                    };
                    updateRequest.onerror = (event) => {
                        console.error('Failed to update data in IndexedDB:', event.target.error);
                        reject(event.target.error);
                    };
                } else {
                    const addRequest = objectStore.add({ key: key, value: value });
                    addRequest.onsuccess = () => {
                        console.log('Data successfully stored in IndexedDB');
                        resolve();
                    };
                    addRequest.onerror = (event) => {
                        console.error('Failed to store data in IndexedDB:', event.target.error);
                        reject(event.target.error);
                    };
                }
            };
        };

        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            const objectStore = db.createObjectStore('userData', { keyPath: 'key' });
            console.log('IndexedDB object store created');
        };
    });
};

export const getUserIDFromIndexedDB = async () => {
    return new Promise((resolve, reject) => {
        const request = window.indexedDB.open('myDatabase', 1);

        request.onerror = (event) => {
            console.error('Failed to open IndexedDB:', event.target.error);
            reject(event.target.error);
        };

        request.onsuccess = (event) => {
            const db = event.target.result;
            const transaction = db.transaction(['userData'], 'readonly');
            const objectStore = transaction.objectStore('userData');

            const getRequest = objectStore.get('UserId');

            getRequest.onsuccess = (event) => {
                const userData = event.target.result;
                if (userData) {
                    console.log('UserId retrieved from IndexedDB:', userData.value);
                    resolve(userData.value);
                } else {
                    console.log('UserId not found in IndexedDB.');
                    resolve(null);
                }
            };

            getRequest.onerror = (event) => {
                console.error('Failed to retrieve UserId from IndexedDB:', event.target.error);
                reject(event.target.error);
            };
        };
    });
};

export const getTokenFromIndexedDB = async () => {
    return new Promise((resolve, reject) => {
        const request = window.indexedDB.open('myDatabase', 1);

        request.onerror = (event) => {
            console.error('Failed to open IndexedDB:', event.target.error);
            reject(event.target.error);
        };

        request.onsuccess = (event) => {
            const db = event.target.result;
            const transaction = db.transaction(['userData'], 'readonly');
            const objectStore = transaction.objectStore('userData');

            const getRequest = objectStore.get('Token');

            getRequest.onsuccess = (event) => {
                const tokenData = event.target.result;
                if (tokenData) {
                    // console.log('Token retrieved from IndexedDB:', tokenData.value);
                    resolve(tokenData.value);
                } else {
                    console.log('Token not found in IndexedDB.');
                    resolve(null);
                }
            };

            getRequest.onerror = (event) => {
                console.error('Failed to retrieve Token from IndexedDB:', event.target.error);
                reject(event.target.error);
            };
        };
    });
};
