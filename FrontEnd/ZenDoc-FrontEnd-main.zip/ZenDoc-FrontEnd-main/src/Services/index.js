import axios from 'axios';
import { getTokenFromIndexedDB } from './IndexDB';

const API = axios.create({
    // baseURL:'http://zenquipserver.herokuapp.com/v1'
    baseURL: 'http://localhost:5000/v1'
});

API.interceptors.request.use(async (config) => {
    // const token = localStorage.getItem('apitoken');
    const token = await getTokenFromIndexedDB();
    // console.log(token);

    if (!token) {
        console.log('Token is not stored in IndexedDB.');
        return config;
    }

    config.headers.Authorization = token;
    return config;
}, error => {
    return Promise.reject(error);
});

export default API;
