// AuthContext.js
import React, { createContext, useState } from 'react';
import { Login } from '../Services/authentication.service';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const login = async (formData, history) => {
    try {
      await Login(formData, history); 
      setIsAuthenticated(true); 
      history.push('/onboard');
   
    } catch (error) {
      setIsAuthenticated(false);
      console.error('Login failed:', error);
    }
  };

  const logout = () => {
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
