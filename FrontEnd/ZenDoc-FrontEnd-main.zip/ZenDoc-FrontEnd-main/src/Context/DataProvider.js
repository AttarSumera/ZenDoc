import React, { createContext, useState, useEffect } from "react";

export const Datacontext = createContext(null);

const DataProvider = ({ children }) => {

  const [account, setAccount] = useState(() => {
    return localStorage.getItem("account") || "";
  });
  const [lastname, setLastname] = useState(() => {
    return localStorage.getItem("lastname") || "";
  });
  const [Salutation, setSalutation] = useState(() => {
    return localStorage.getItem("lastname") || "";
  });
  

  const [completeProfilePercenrtage, setCompleteProfilePercenrtage] = useState('')

  useEffect(() => {
    localStorage.setItem("account", account);
    localStorage.setItem("lastname", lastname);
  }, [account, lastname]);

  return (
    <Datacontext.Provider
      value={{
        account,
        setAccount,
        lastname,
        setLastname,
        completeProfilePercenrtage,
        setCompleteProfilePercenrtage,
        Salutation,
        setSalutation
      }}
    >
      {children}
    </Datacontext.Provider>
  );
};

export default DataProvider;
