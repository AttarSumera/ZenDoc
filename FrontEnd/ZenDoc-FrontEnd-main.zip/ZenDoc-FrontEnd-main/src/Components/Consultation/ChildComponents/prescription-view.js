import React, { useState } from 'react';
import AddPrescription from './DrugPrescription/addPrescriptoin-view';
import PrescriptionSummary from './DrugPrescription/prescription-summary';
import AddPharmaPres from './PharmaPrescription/addPharma-view';
import '../../../style/consultation/prescript-view.css';
import NonPharmaSummary from './DrugPrescription/Non-pharma-summary';

const Prescription = () => {

    const [showAddPrescription, setShowAddPrescription] = useState(true);

    const handleAddDrugClick = () => {
        setShowAddPrescription(false);
    };
    const [tabHeader, setTabHeader] = useState('1');

    const tabClickHandler = (event) => {
        const tabId = event.target.getAttribute('name');
        setTabHeader(tabId);
    };

    const getTabClassName = (tabId) => {
        return tabHeader === tabId ? 'pres-tab-selected' : 'pres-tab-not-selected';
    };

    const drugTabclass = 'border-radius-l press-tab' + (tabHeader === '1' ? ' pres-tab-selected' : '');
    const pharmsTabclass = 'border-radius-r press-tab' + (tabHeader === '2' ? ' pres-tab-selected' : '');

    return (
        <div className='con-pres-parent'>
            <div className='pres-header'>
                <div className='pres-header--label'>
                    Write Prescription
                </div>
                <div className='press-headercontent'>
                    <div className='pres-header--img img-cst image-basic'>
                        CST
                    </div>
                    <div className='pres-header--img img-print image-basic'>
                        Print
                    </div>
                </div>
            </div>
            <div className='pres-tab-header'>
                <div onClick={tabClickHandler} tabIndex='1' name='1' className={drugTabclass}>
                    Drug Prescription
                </div>
                <div onClick={tabClickHandler} tabIndex='1' name='2' className={pharmsTabclass}>
                    Non-Pharma Prescription
                </div>
            </div>
            <div className='pres-tab-body'>
                {tabHeader === '1' &&
                    <div className='pres-body-parent'>
                        {showAddPrescription ? (
                            <AddPrescription handleAddDrugClick={handleAddDrugClick} />
                        ) : (
                            <PrescriptionSummary />
                        )}
                    </div>
                }
                {tabHeader === '2' &&
                    <div>
                        <AddPharmaPres />
                        {/* <NonPharmaSummary /> */}
                    </div>
                }
            </div>
        </div>
    );
}

export default Prescription;
