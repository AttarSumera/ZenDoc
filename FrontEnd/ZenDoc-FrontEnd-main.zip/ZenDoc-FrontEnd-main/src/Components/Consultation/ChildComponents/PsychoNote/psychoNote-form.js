import React from 'react';
import { connect, useDispatch } from 'react-redux';
import PsychoNoteInput from '../PsychoNoteForm/psychoNote-input';
import { writePsychoNote as PsycNote, getPsychoNoteDetails as fetchPsychoNoteDetails } from '../../../../Actions/consultation';

const PsychoNoteForm = ({ patientID, docID }) => {
    const dispatch = useDispatch();

    const writePsychoNote = () => {
        dispatch(PsycNote(false));
    }

    const getPsychoNoteDetails = () => {
        dispatch(fetchPsychoNoteDetails({
            patID: patientID,
            userID: docID
        }));
    }

    return (
        <div className='doc-note-form'>
            <div className='dnf-header2'>
                <div className='fas fa-arrow-left dnf-back' onClick={writePsychoNote}></div>
                <div className='dnf-header-text'><b>Psychotherapy note</b></div>
                <div onClick={getPsychoNoteDetails} className='dnf-last-note'>View Last Note</div>
            </div>
            <div className='dnf-body'>
                <PsychoNoteInput />
            </div>
        </div>
    );
}


const mapStatetoProps = (state) => {

    const patientID = state.patientDetails.patientInfo.patientid ? state.patientDetails.patientInfo.patientid : null;
    const docID = state.login.userID;

    return {
        patientID: patientID,
        docID: docID
    };
};

export default connect(mapStatetoProps)(PsychoNoteForm);
