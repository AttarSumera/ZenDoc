import React from 'react'

const psychoNoteGoals = () => {
    return (
        <div>
            psychoNoteGoals
        </div>
    )
}

export default psychoNoteGoals