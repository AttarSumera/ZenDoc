import React from 'react';

const DoctorNoteDiagnosis = ({ diagnosis, handleDiseaseInputChange }) => {
  return (
    <>
      <div className='dnc-diagnosis'>
        <div className='dn-body-number-parent'>
          <div className='dn-body-number-sub2'>6</div>
          <label className='label-basic'>Provisional Diagnosis</label>
        </div>
        <textarea
          onChange={(e) => handleDiseaseInputChange(e)}
          name="provisionalDiagnosis"
          value={diagnosis.provisionalDiagnosis}
          className='form-control'
          placeholder="Provisional Diagnosis"
        />
      </div>

      <div className='dnc-pe'>
        <div className='dn-body-number-parent'>
          <div className='dn-body-number-sub2'>7</div>
          <label className='label-basic'>Physical Examination</label>
        </div>
        <div className='dnc-pe-inputs'>
          <div>
            <label className='labelA'>Blood Pressure</label>
            <input 
              name="physicalExam_BP"
              value={diagnosis.physicalExam_BP}
              onChange={(e) => handleDiseaseInputChange(e)}
              className='form-control DrugP-Form'
            />
          </div>
          <div>
            <label className='labelA'>Pulse rate</label>
            <input 
              name="physicalExam_pulse"
              value={diagnosis.physicalExam_pulse}
              onChange={(e) => handleDiseaseInputChange(e)}
              className='form-control DrugP-Form'
            />
          </div>
          <div>
            <label className='labelA'>Height (cm)</label>
            <input 
              name="physicalExam_height"
              value={diagnosis.physicalExam_height}
              onChange={(e) => handleDiseaseInputChange(e)}
              className='form-control DrugP-Form'
            />
          </div>
          <div>
            <label className='labelA'>Weight(kg)</label>
            <input 
              name="physicalExam_weight"
              value={diagnosis.physicalExam_weight}
              onChange={(e) => handleDiseaseInputChange(e)}
              className='form-control DrugP-Form'
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default DoctorNoteDiagnosis;
