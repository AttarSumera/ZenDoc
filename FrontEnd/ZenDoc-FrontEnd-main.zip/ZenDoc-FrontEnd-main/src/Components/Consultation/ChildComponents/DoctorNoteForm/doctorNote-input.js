import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import DoctorNoteDiseaseInput from './doctorNote-diseaseinput';
import DoctorNoteComplaints from './doctorNote-complaints';
import DoctorNoteDiagnosis from './doctorNote-diagnosis';
import { saveDoctorNote, writeDoctorNote } from '../../../../Actions/consultation';
import '../../../../style/consultation/doctorNote-form.css';

const DoctorNoteInput = ({ patientID, docID, saveDoctorNote, writeDoctorNote }) => {
    const [state, setState] = useState({
        patientID: patientID,
        doctorID: docID,
        guardianID: '',
        guardianName: '',
        illnessType: 1,
        illnessDurationUnit: '',
        illnessDurationNumber: '',
        relevantHistory: '',
        patChiefComplaints: '',
        pastHistory: '',
        personaTemperTraits: '',
        MSE_GAB: '',
        MSE_PMA: '',
        MSE_speech_quantity: '',
        MSE_speech_rate: 2,
        MSE_speech_tone: '',
        MSE_speech_volume: '',
        MSE_speech_reactionTime: '',
        MSE_mood_affect: '',
        MSE_thought_content: '',
        MSE_thought_possession: '',
        MSE_perception: '',
        MSE_HMFCogn: '',
        provisionalDiagnosis: '',
        physicalExam_BP: '',
        physicalExam_pulse: '',
        physicalExam_height: '',
        physicalExam_weight: ''
    });
    
    // useEffect(() => {
    //     console.log('docID:', docID);
    // }, [docID]);


    const handleDiseaseInputChange = (event) => {
        const { name, value } = event.target;
        setState(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const saveDoctorNoteHandler = () => {
        saveDoctorNote({ ...state });
    };

    const cancelDoctorNote = () => {
        writeDoctorNote(false);
    };

    return (
        <>
            <DoctorNoteDiseaseInput info={state} handleDiseaseInputChange={handleDiseaseInputChange} />
            <DoctorNoteComplaints complaints={state} handleDiseaseInputChange={handleDiseaseInputChange} />
            <DoctorNoteDiagnosis diagnosis={state} handleDiseaseInputChange={handleDiseaseInputChange} />
            <div className='doctornote-inputfooter'>
                <button className="button-basics avg-button transparent-button" onClick={cancelDoctorNote}>Reset</button>
                <button onClick={saveDoctorNoteHandler} className="button-basics avg-button transparent-button--blue">Save Note</button>
            </div>
        </>
    );
};

const mapStatetoProps = (state) => {

    const patientID = state.patientDetails.patientInfo.patientid ? state.patientDetails.patientInfo.patientid : null;
    const docID = state.login.userID;

    return {
        patientID: patientID,
        docID: docID
    };
};


export default connect(mapStatetoProps, {
    saveDoctorNote,
    writeDoctorNote
})(DoctorNoteInput);
