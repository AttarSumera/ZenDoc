import React from "react";
import Group from "../../../../style/images/Group 2523.svg";
import "../../../../style/consultation/docterNote-save.css";
import "../../../../style/consultation/SavePsychoNote.css";

const SaveNote = () => {
  return (
    <div className="patientsavenote">
      <div className="paitent-info-sn">
        <div>
          <div className="sn-title">
            <img src={Group} alt="Group icon" />
            <span className="sn-head">Gardian Name</span>
          </div>

          <div className="sn-title">
            <img src={Group} alt="Group icon" />
            <span className="sn-head">Relationship with patient</span>
          </div>

          <div className="sn-title">
            <img src={Group} alt="Group icon" />
            <span className="sn-head">Problem</span>
          </div>

          <div className="sn-title">
            <img src={Group} alt="Group icon" />
            <span className="sn-head">Duration of illness</span>
          </div>
        </div>

        <div>
          <div className="sn-titlevalue">
            <span className="sn-para">Akram Malik</span>
          </div>
          <div className="sn-titlevalue">
            <span className="sn-para">Friend</span>
          </div>
          <div className="sn-titlevalue">
            <span className="sn-para">Depression</span>
          </div>
          <div className="sn-titlevalue">
            <span className="sn-para">21 Week</span>
          </div>
        </div>
      </div>

      <div className="patientsavenote">
        <div className="dn-body-number-parent">
          <div className="dn-body-number-sub2">1</div>
          <label className="label-basic">paitent's chief complaints</label>
        </div>
        <div className="dnc-pe-inputs">
          <span className="data-sn">
            The core symptom of depression is said to be anhedonia. which refers
            to loss of interest or a loss of feeling of pleasure in certain
            activities that useually bring joy to people.
          </span>
        </div>
      </div>

      <div className="patientsavenote">
        <div className="dn-body-number-parent">
          <div className="dn-body-number-sub2">2</div>
          <label className="label-basic">Relavant History</label>
        </div>
        <div className="dnc-pe-inputs">
          <span className="data-sn">
            Depressed mood is a symptom of some mood disorders such as major
            depressive disorder or dysthymia.
          </span>
        </div>
      </div>

      <div className="patientsavenote">
        <div className="dn-body-number-parent">
          <div className="dn-body-number-sub2">2</div>
          <label className="label-basic">Relavant History</label>
        </div>
        <div className="dnc-pe-inputs">
          <span className="data-sn">
            Depressed mood is a symptom of some mood disorders such as major
            depressive disorder or dysthymia.
          </span>
        </div>
      </div>

      <div className="patientsavenote">
        <div className="dn-body-number-parent">
          <div className="dn-body-number-sub2">3</div>
          <label className="label-basic">Past History</label>
        </div>
        <div className="dnc-pe-inputs">
          <span className="data-sn">
            Depressed mood is a symptom of some mood disorders such as major
            depressive disorder or dysthymia.
          </span>
        </div>
      </div>

      <div className="patientsavenote">
        <div className="dn-body-number-parent">
          <div className="dn-body-number-sub2">4</div>
          <label className="label-basic">
            Personality / Temperament Traits
          </label>
        </div>
        <div className="dnc-pe-inputs">
          <span className="data-sn">
            Depressed mood is a symptom of some mood disorders such as major
            depressive disorder or dysthymia.
          </span>
        </div>
      </div>

      <div className="patientsavenote">
        <div className="dn-body-number-parent">
          <div className="dn-body-number-sub2">5</div>
          <label className="label-basic">
            Mental status Examination findings (MSE)
          </label>
        </div>
        <div className="dnc-pe-inputs">
          <ul
            style={{
              listStyleImage:
                "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%231E64CC' viewBox='0 0 24 24'%3E%3Ccircle cx='12' cy='12' r='8'/%3E%3C/svg%3E\")",
            }}
          >
            <div className="DocterNoteli">
              <li className="docternoteli_sub">GAB (General Appearance and behaviour )</li>
              <p>-</p>
              <p className="docternotepara">Depressed mood is a symptom of some mood disorders</p>
            </div>

            <div className="DocterNoteli">
              <li className="docternoteli_sub">PMA (Psychomotor activity )</li>
              <p>-</p>
              <p className="docternotepara">
                Depressive disorder or dysthymia; it is a normal temporary
                reaction to life events
              </p>
            </div>

            <div className="DocterNoteli">
              <li className="docternoteli_sub">Speech</li>
              <p>-</p>
              <p className="docternotepara">
                Quantity <span>Low</span>
              </p>
            </div>

            <div className="DocterNoteli">
              <li className="docternoteli_sub">Mood & Affect</li>
              <p>-</p>
              <p className="docternotepara">Depressed mood is a symptom of some mood disorders</p>
            </div>

            <div className="DocterNoteli">
              <li className="docternoteli_sub"  >Thought</li>
              <p>-</p>
              <p className="docternotepara">Major depressive disorder or dysthymia;</p>
            </div>

            <div className="DocterNoteli">
              <li className="docternoteli_sub">Perception</li>
              <p>-</p>
              <p className="docternotepara">Some physical diseases and a side effect of some drugs</p>
            </div>
          </ul>
        </div>
      </div>

      <div className="patientsavenote">
        <div className="dn-body-number-parent">
          <div className="dn-body-number-sub2">6</div>
          <label className="label-basic">Provisional diagnosis</label>
        </div>
        <div className="dnc-pe-inputs">
          <span className="data-sn">
            Depressed mood is a symptom of some mood disorders such as major
            depressive disorder or dysthymia.
          </span>
        </div>
      </div>

      <div className="patientsavenote">
        <div className="dn-body-number-parent">
          <div className="dn-body-number-sub2">7</div>
          <label className="label-basic">Physical examination</label>
        </div>
        <div className="dnc-pe-inputs">
          <div className="sn-physexam">
            <div>
              <span className="sn-field">Blood pressure</span>
              <span className="sn-fieldval">150</span>
            </div>
            <div>
              <span className="sn-field">Pulse rate</span>
              <span className="sn-fieldval">150</span>
            </div>
            <div>
              <span className="sn-field">Height</span>
              <span className="sn-fieldval">150</span>
            </div>
            <div>
              <span className="sn-field">Weight</span>
              <span className="sn-fieldval">150</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SaveNote;
