import React from 'react';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';

const DoctorNoteDiseaseInput = ({ info, handleDiseaseInputChange }) => {

  return (
    <>
      <div className='dis-input-gr'>
        <div className='dis-input-guardian'>
          <label className='label-basic'>Guardian Name</label>
          <input
            value={info.guardianName}
            name='guardianName'
            onChange={(e) => handleDiseaseInputChange(e)}
            className='form-control'
            placeholder='Enter Guardian Name'
          />
          <label className='label-basic gray-label'>If there is no guardian leave blank</label>
        </div>
        <div className='dis-input-rel'>
          <label className='label-basic'>Relationship</label>
          <FormControl className="zenquip-select" fullWidth>
            <InputLabel id="relation-select-label">Relationship</InputLabel>
            <Select
              name="guardianID"
              labelId="relation-select-label"
              id="relation-select"
              label="Relationship"
              value={info.guardianID}
              onChange={(e) => handleDiseaseInputChange(e)}
            >
              <MenuItem value={1}>Cousin</MenuItem>
              <MenuItem value={2}>Father</MenuItem>
              <MenuItem value={3}>Mother</MenuItem>
            </Select>
          </FormControl>
          <label className='label-basic gray-label'>Select the relationship of Guardian with patient</label>
        </div>
      </div>
      <div className='dnc-diagnosis'>
        <div className='dn-body-number-parent'>
          <label className='label-basic'>Problem</label>
        </div>
        <textarea
          onChange={(e) => handleDiseaseInputChange(e)}
          name="provisionalDiagnosis"
          value={info.provisionalDiagnosis}
          className='form-control'
          placeholder="Provisional Diagnosis"
        />
      </div>
      <div className='dis-input-illness'>
        <div className='dis-input-illness-dur'>
          <label className='label-basic'>Duration of Illness</label>
          <div className='illness-duration-selects'>
            <FormControl className="zenquip-select halfWidth">
              <Select
                labelId="illness-dur-select-label"
                id="illness-dur-select"
                label="Illness"
                name="illnessDurationUnit"
                value={info.illnessDurationUnit}
                onChange={(e) => handleDiseaseInputChange(e)}
              >
                <MenuItem value={1}>Day</MenuItem>
                <MenuItem value={2}>Week</MenuItem>
                <MenuItem value={3}>Month</MenuItem>
              </Select>
            </FormControl>
            <input
              value={info.illnessDurationNumber}
              onChange={(e) => handleDiseaseInputChange(e)}
              name='illnessDurationNumber'
              className="form-control ml10"
              placeholder="0"
            />
          </div>
          <label className='label-basic gray-label'>E.g. For 3 weeks, select Week and enter 3</label>
        </div>
      </div>
    </>
  );
};

export default DoctorNoteDiseaseInput;
