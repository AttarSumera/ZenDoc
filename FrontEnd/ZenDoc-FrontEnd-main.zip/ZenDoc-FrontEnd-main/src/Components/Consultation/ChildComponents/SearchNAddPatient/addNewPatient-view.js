import React, { useState } from "react";
import { connect } from "react-redux";
import Modal from "react-bootstrap/Modal";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
// import { AddNewPatientService } from '../../../../Services/AddNewPatient.service'

import {
  addAndLoadPatient,
  addNewPatientFlag,
} from "../../../../Actions/consultation";
import "../../../../style/dashBoard/addNewPatient.css";

const AddNewPatient = ({
  addNewPatient,
  doctorID,
  addAndLoadPatient,
  addNewPatientFlag,
}) => {
  const [formData, setFormData] = useState({
    patientName: "",
    sex: "",
    emailAddress: "",
    mobileNumber: "",
    age:""
  });

  const { patientName, sex, emailAddress, mobileNumber,age } = formData

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = () => {
    // AddNewPatientService(formData)
    // console.log(formData)
    addAndLoadPatient({ ...formData, doctorId: doctorID });
  };

  const handleCancel = () => {
    addNewPatientFlag(false);
  };

  return (
    <>
      <Modal
        dialogClassName="custom-modal"
        show={addNewPatient}
        onHide={handleCancel}
        centered
      >
        <Modal.Header closeButton className="AddPatientHeader">
          <Modal.Title>
            <div className="np-patient-label">
              <label>Add New Patient</label>
            </div>
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="AddPatientBody">
          <div className="np-patient-name np-parentcontainer">
            <label className="np-label">Patient Name</label>
            <input
              value={patientName}
              className="form-control"
              onChange={handleChange}
              name="patientName"
              placeholder="Patient Name"
            />
          </div>
          <div className="np-gender-age np-parentcontainer">
            <div className="np-gender">
              <label id className="np-label">
                Sex
              </label>
              <Select
                id="ap-sex-select"
                className="zenquip-select-gender"
                value={sex}
                label="Sex"
                name="sex"
                onChange={handleChange}
              >
                <MenuItem value={"Male"}>Male</MenuItem>
                <MenuItem value={"Female"}>Female</MenuItem>
                <MenuItem value={3}>Prefer Not to say</MenuItem>
              </Select>
            </div>
            <div className="np-age">
              <label className="np-label">Age</label>
              <input
                className="form-control"
                onChange={handleChange}
                name="age"
                value={age}
                placeholder="Age"
              />
            </div>
          </div>
          <div className="np-mail-parent np-parentcontainer">
            <div className="np-mail-label">
              <label className="np-label">
                Email Address <span>(Optional)</span>
              </label>
            </div>
            <div className="np-mail-text">
              <div className="np-mail-input">
                <input
                  value={emailAddress}
                  onChange={handleChange}
                  className="form-control"
                  name="emailAddress"
                  placeholder="Enter email id"
                />
              </div>
            </div>
          </div>
          <div className="np-mail-parent">
            <div className="np-mail-label">
              <label className="np-label">Mobile</label>
              <span>Send Verification</span>
            </div>
            <div className="np-mail-text">
              <div className="np-mail-input">
                <input
                  value={mobileNumber}
                  onChange={handleChange}
                  className="form-control"
                  name="mobileNumber"
                  placeholder="Enter Mobile No"
                />
              </div>
              <div className="np-mail-otp">
                <input className="form-control" placeholder="Enter OTP" />
                <button className="AddPatientVerifyBTN">Verify</button>
              </div>
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer
          className="AddPatientFooter"
          style={{ padding: "1.5rem" }}
        >
          <div className="np-buttonbar">
            <button className="button AddPatientBTN" onClick={handleCancel}>
              Cancel
            </button>
            <button
              className="button orange-button avg-button"
              onClick={handleSubmit}
            >
              Add New
            </button>
          </div>
        </Modal.Footer>
      </Modal>
    </>
  );
};

const mapStatetoProps = (state) => {
  return {
    addNewPatient: state.patientDetails.addNewPatient,
    doctorID: state.login.userID,
  };
};

export default connect(mapStatetoProps, {
  addAndLoadPatient: addAndLoadPatient,
  addNewPatientFlag: addNewPatientFlag,
})(AddNewPatient);
