import React from "react";
import { connect } from "react-redux";

import SearchPatientInfo from "./searchPatientInfo";
import { addNewPatientFlag } from "../../../../Actions/consultation";
import "../../../../style/consultation/searchnAddPatient-view.css";

const SearchPatient = ({ patientsList, addNewPatientFlag }) => {
    const handleAddNewPatient = () => {
        addNewPatientFlag(true);
    };

    const renderPatients = () => {
        if (!patientsList || !Array.isArray(patientsList)) {
            return null;
        }
        console.log("PATIENT LIST: ", patientsList)
        return patientsList.map((patient) => (
            <SearchPatientInfo key={patient.UserId} patient={patient} />
            
        ));
    };


    return (
        <div className="con-sp-parent">
            <div className="con-sp-header">Search Result</div>
            {patientsList && (
                <div className="con-sp-addPatient">
                    <span>
                        This Email address Is not available. To continue click add patient
                    </span>
                    <button
                        onClick={handleAddNewPatient}
                        className="button blue-buttonadd small-button"
                    >
                        Add Patient
                    </button>
                </div>
            )}
            <div className="con-sp-body">{renderPatients()}</div>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        patientsList: state.patientDetails.patientsList,
    };

};

export default connect(mapStateToProps, {
    addNewPatientFlag,
})(SearchPatient);