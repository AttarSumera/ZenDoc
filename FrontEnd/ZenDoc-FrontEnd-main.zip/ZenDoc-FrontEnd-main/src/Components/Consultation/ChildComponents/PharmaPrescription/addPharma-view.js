import React from 'react';
import { connect } from 'react-redux';

import AddTools from './addTools-view';

import '../../../../style/consultation/addtools-view.css';

const AddPharmaPres = (props) => {
    return (
        <div className='add-ph-parent'>
            <AddTools />
        </div>
    );
}

export default connect()(AddPharmaPres);
