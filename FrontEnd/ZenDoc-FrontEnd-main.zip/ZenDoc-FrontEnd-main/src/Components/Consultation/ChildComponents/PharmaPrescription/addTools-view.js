import React, { useState } from 'react';
import { toolsList } from '../../toolsList';
import ToolDetails from './toolDetails';
import NonPharmaSummary from '../DrugPrescription/Non-pharma-summary';

const AddTools = () => {
    const [selectedTool, setSelectedTool] = useState(-1);
    const [showToolDetails, setShowToolDetails] = useState(false); // State to manage whether to show ToolDetails or NonPharmaSummary

    const generateToolsList = () => {
        let list = toolsList.map((tool) => (
            <div
                key={tool.id}
                className={`pharma-tool${tool.id === selectedTool ? ' selected-tool' : ''}`}
                onClick={() => handleToolClick(tool.id)}
                style={{ backgroundColor: tool.id === 7 && selectedTool === 7 ? '#1E64CC' : '', color: tool.id === 7 && selectedTool === 7 ? '#ffffff' : '#205fbf' }}
            >
                {tool.title}
            </div>
        ));
        return list;
    };

    const handleToolClick = (toolId) => {
        if (toolId === selectedTool) {
            // If the same tool is clicked again, hide ToolDetails
            setShowToolDetails(!showToolDetails);
        } else {
            setSelectedTool(toolId);
            if (toolId === 7) {
                setShowToolDetails(true); // Show ToolDetails only if De-addiction Tool is clicked
            } else {
                setShowToolDetails(false); // Hide ToolDetails for other tools
            }
        }
    };

    const handleAddTask = () => {
        setShowToolDetails(false); // Hide ToolDetails when Add Task is clicked
    };

    return (
        <>
            <div className='add-tool-header'>
                Write Therapy Task or Goal
            </div>
            <textarea className='form-control'></textarea>
            <label className='gray-label label-basic'>Eg. Meet new people to overcome crowd stress.</label>
            <div className='pharma-tool-list'>{generateToolsList()}</div>
            {selectedTool === 7 && showToolDetails ? <ToolDetails handleAddTask={handleAddTask} /> : <NonPharmaSummary />}
        </>
    );
};

export default AddTools;
