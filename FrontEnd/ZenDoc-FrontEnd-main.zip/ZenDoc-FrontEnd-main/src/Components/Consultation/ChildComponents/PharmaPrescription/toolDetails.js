import React from 'react';

const ToolDetails = ({ handleAddTask, selectedTool }) => {
    return (
        <>
            <div className='tool-method'>
                <label className='BoldL'>Select type of method in de-addiction</label>
                <div>
                    <select className='form-control tooldetailselect'>
                        {/* Add your options here */}
                        <option value='option1'>Relapse prevention</option>
                        <option value='option2'>Option 2</option>
                        {/* Add more options as needed */}
                    </select>
                </div>

            </div>

            <div className='tool-duration'>
                <div className='tool-delay'>
                    <label className='BoldL'>Set delay time</label>
                    <div className='time-picker-container'>
                        <div className='time-section'>
                            <input type='number' min='1' max='12' className='time-input' />
                        </div>
                        <div className='time-section'>
                            <input type='number' min='0' max='59' className='time-input' />
                        </div>
                        <div className='time-section time-section-3'>
                            <select className='time-input time-input2'>
                                <option value='AM'>AM</option>
                                <option value='PM'>PM</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div className='tool-duration-unit'>
                    <div className='tool-duration-unit-sub'>
                        <label className='BoldL'>Duration</label>
                        <div>
                            <select className='duration-dropdown2'>
                                <option value='1'>Week</option>
                                <option value='2'>2 Weeks</option>
                            </select>
                            <input type='number' className='duration-number2' min='1' max='30' />
                        </div>
                    </div>
                </div>
            </div>
            <div className='medicine-advice-labels'>
                <div className='lable basic'>
                    Motivation Message
                </div>
                <div className='label-basic record-voice'>
                    Record Voice
                    <i className="fas fa-microphone" style={{ marginLeft: '5px' }}></i> {/* Add the voice icon here */}
                </div>
            </div>
            <div className='tool-message'>
                <input className='form-control' placeholder='Write Any Message' />
                <label className='gray-label label-basic'>Write any motivation message/quote</label>
            </div>
            <div className='tool-contact'>
                <label className='BoldL' placeholder='Enter support person number'>Support Person Contact</label>
                <input className='form-control' />
                <label className='gray-label label-basic'>Eg enter patient's friends number who gives emotional support.</label>
            </div>
            <div className="ToolDetailBTNG">
                <button className=''>Close</button> {/* Update onClick to call handleAddTask */}
                <button className='' onClick={handleAddTask}>
                    <i className="fas fa-plus" style={{ marginRight: '15px' }}></i> 
                    Add Task
                </button>
            </div>
        </>
    );
};

export default ToolDetails;
