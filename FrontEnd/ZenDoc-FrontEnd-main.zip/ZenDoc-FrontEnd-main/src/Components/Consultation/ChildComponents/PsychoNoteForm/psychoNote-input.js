import React, { useState } from 'react';
import { connect } from 'react-redux';
import { writePsychoNote, savePsychoNote } from '../../../../Actions/consultation';

import PsychoNoteGuardian from './psychoNote-guardian';
import PsychoNoteSession from './psychoNote-symptom';
import PsychoNoteChiefComplaints from './psychoNote-diagnosis';
import PsychoNoteCurrentDiagnosis from './psychoNote-cSymptom';
import PsychoNoteSessionContent from './psychoNote-events';
import PsychoNoteMedication from './pschoNote-medication';
import PsychoNoteGoalAssignment from './psychonote-safety';
import PsychoNoteProgress from './psychoNote-progress';
import PsychoNoteGoalsProgress from './psychoNote-goals';
import RevisedGoals from './psychoNote-Revised Goals';

const PsychoNoteForm = ({ patientID, docID, writePsychoNote, savePsychoNote }) => {
    const [state, setState] = useState({
        patientID: patientID,
        doctorID: docID,
        guardianName: '',
        relationship: '',
        sessionNumber: '',
        sessionDuration: '',
        chiefComplaints: '',
        primaryDiagnosis: '',
        sessionContent: {
            generalAppearance: '',
            rapport: '',
            moodAndAffect: '',
            miscellaneousFindings: '',
            sessionAgenda: ''
        },
        interventionAndTechniques: '',
        patientProgress: '',
        plansAndGoals: '',
        otherFindings: ''
    });

    const handleChange = (event) => {
        const { name, value } = event.target;
        setState(prevState => ({
            ...prevState,
            [name]: value,
            sessionContent: { ...prevState.sessionContent, [name]: value } 
        }));
    };


    const saveNoteHandler = () => {
        savePsychoNote({ ...state });
    };

    const cancelPsychoNote = () => {
        writePsychoNote(false);
    };

    const info = {
        guardianName: state.guardianName || '',
        relationship: state.relationship || ''
    };

    const chiefComplaints = {
        chiefComplaints: state.chiefComplaints || '',
        isDiagnosticChange: state.isDiagnosticChange || ''
    };

    const Session = {
        sessionNumber: state.sessionNumber || '',
        sessionDuration: state.sessionDuration || ''
    }

    const { generalAppearance, rapport, moodAndAffect, miscellaneousFindings, sessionAgenda } = state.sessionContent;

    return (

        <React.Fragment>
            <PsychoNoteGuardian info={info} handleChange={handleChange} />
            <PsychoNoteSession Session={Session} handleChange={handleChange} />
            <PsychoNoteChiefComplaints chiefComplaints={chiefComplaints} handleChange={handleChange} />
            <PsychoNoteCurrentDiagnosis primaryDiagnosis={state.primaryDiagnosis} handleChange={handleChange} />

            <PsychoNoteSessionContent
                sessionContent={{ generalAppearance, rapport, moodAndAffect, miscellaneousFindings, sessionAgenda }}
                handleChange={handleChange}
            />

            <PsychoNoteGoalAssignment interventionAndTechniques={state.interventionAndTechniques} handleChange={handleChange} />
            <PsychoNoteGoalsProgress patientProgress={state.patientProgress} handleChange={handleChange} />
            <RevisedGoals plansAndGoals={state.plansAndGoals} handleChange={handleChange} />
            <PsychoNoteProgress otherFindings={state.otherFindings} handleChange={handleChange} />
            <div className='psychonote-inputfooter'>
                <button onClick={cancelPsychoNote} className="button-basics avg-button transparent-button">Reset</button>
                <button onClick={saveNoteHandler} className="button-basics avg-button transparent-button--blue">Save Note</button>
            </div>
        </React.Fragment>

    );
};

const mapStatetoProps = (state) => {
    return {
        patientID: state.patientDetails.patientInfo?.UserId,
        docID: state.login.userID
    };
};

export default connect(mapStatetoProps, {
    writePsychoNote,
    savePsychoNote
})(PsychoNoteForm);