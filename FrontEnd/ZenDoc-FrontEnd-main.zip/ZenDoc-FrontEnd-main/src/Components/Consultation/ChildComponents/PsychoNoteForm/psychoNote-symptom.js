import React, { useState } from 'react';

// External Imports
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';

const PsychoNoteSession = (props) => {
    const [duration, setDuration] = useState('');
    const [unit, setUnit] = useState('minutes');

    const handleChange = (e) => {
        const { name, value } = e.target;
        if (name === 'duration') {
            setDuration(value);
        } else if (name === 'unit') {
            setUnit(value);
        }
    };

    return (
        <>
            <div className='dis-input-gr'>
                <div className='dis-input-guardian'>
                    <label className='label-basic'>Session number</label>
                    <input value={props.Session.sessionNumber} name='sessionNumber' onChange={(e) => props.handleChange(e)} className='form-control' placeholder='Enter Session Number' />
                </div>
                <div className='dis-input-guardian'>
                    <label className='label-basic'>Duration of session</label>
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                        <input value={props.Session.sessionDuration} name='sessionDuration' onChange={(e) => props.handleChange(e)} className='form-control' placeholder='Enter Duration' style={{ height: '35px' }} />
                        <FormControl style={{ minWidth: 60, height: '35px' }}>
                            <InputLabel id="unit-label">Unit</InputLabel>
                            <Select
                                labelId="unit-label"
                                id="unit"
                                name='unit'
                                value={unit}
                                onChange={(e) => props.handleChange(e)}
                                style={{ height: '100%' }}
                            >
                                <MenuItem value="minutes">Minutes</MenuItem>
                                <MenuItem value="hours">Hours</MenuItem>
                            </Select>
                        </FormControl>
                    </div>
                </div>
            </div>
        </>
    );
};

export default PsychoNoteSession;
