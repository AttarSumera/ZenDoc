import React from 'react';
import { useSelector } from 'react-redux';

const PatientInfo = () => {
    const patientDetails = useSelector(state => state.patientDetails.patientInfo);

    const getAge = (dateString) => {
        var today = new Date();
        var birthDate = new Date(dateString);
        var age = today.getFullYear() - birthDate.getFullYear();
        var m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        return age;
    }

    return (
        <div className='pinfo'>
            <div className='pinfo-pic'>
                <div className='pinfo-img'></div>
                <div className='pinfo__name'>
                    <div className='pinfo-flexcontainer-column'>
                        <span className='pinfo--name-label pinfo-labels'>Patient's Name</span>
                        <div className='pinfo--name pinfo-text'>{patientDetails?.firstName ? (patientDetails.firstName + " " + patientDetails.lastName) : "Name"}</div>
                    </div>
                    <div className='pinfo-flexcontainer-column'>
                        <div className='pinfo-flexcontainer'>
                            <span className='pinfo--age-label pinfo-labels'>Age</span>
                            <span className='pinfo--gender-label pinfo-labels'>Sex</span>
                        </div>
                        <div className='pinfo-flexcontainer'>
                            {/* <div className='pinfo--age pinfo-text'>{patientDetails?.dateOfBirth ? getAge(patientDetails.dateOfBirth) : "Age"}</div> */}
                            <div className='pinfo--age pinfo-text'>{patientDetails?.age ?  patientDetails?.age : ''}</div>
                            <div className='pinfo--gender pinfo-text'>{patientDetails?.gender ? patientDetails?.gender : "Female"}</div>
                        </div>
                    </div>
                </div>
            </div>
            <div className='pinfo__contacts'>
                <div className='pinfo__contacts-container'>
                    <div className='pinfo__mail-parent pinfo__contacts--label'>
                        <span className='pinfo-labels'>Email Address</span>
                        <div className='pinfo__mail pinfo-text'>{patientDetails?.emailID ? patientDetails?.emailID : ''}</div>
                    </div>
                    <div className='pinfo__mobile-parent pinfo__contacts--label'>
                        <span className='pinfo-labels'>Mobile</span>
                        <div className='pinfo__mobile pinfo-text'>{patientDetails?.phoneNumber ? patientDetails?.phoneNumber : ''}</div>
                    </div>
                    <div className='pinfo__consulting-parent pinfo__contacts--label'>
                        <span className='pinfo-labels'>Consulting</span>
                        <div className='pinfo__consulting pinfo-text'></div>
                    </div>
                    <div className='pinfo__last-sesion-parent pinfo__contacts--label'>
                        <span className='pinfo-labels'>Last Session</span>
                        <div className='pinfo__last-session pinfo-text'></div>
                    </div>
                </div>
                <div className='pinfo__activity-container'>
                    <div className='pinfo__activity'>
                        <i></i>
                        <div>Activity tracking</div>
                    </div>
                    <div className='pinfo__lab'>
                        <i></i>
                        <div>Lab reports</div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default PatientInfo;
