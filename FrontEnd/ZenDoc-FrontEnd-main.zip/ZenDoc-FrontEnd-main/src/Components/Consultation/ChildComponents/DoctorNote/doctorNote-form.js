import React from 'react';
import { connect, useDispatch } from 'react-redux';
import DoctorNoteInput from '../DoctorNoteForm/doctorNote-input';
import { writeDoctorNote as DocNote, getDoctorNoteDetails as fetchDoctorNoteDetails } from '../../../../Actions/consultation';
import '../../../../style/consultation/doctorNote-form.css'


const DoctorNoteForm = ({ patientID, docID }) => {
    const dispatch = useDispatch();

    const writeDoctorNote = () => {
        dispatch(DocNote(false));
    }

    const getDoctorNoteDetails = () => {
        dispatch(fetchDoctorNoteDetails({
            patID: patientID,
            userID: docID
        }));
    }

    return (
        <div className='doc-note-form'>
            <div className='dnf-header2'>
                <div className='fas fa-arrow-left dnf-back' onClick={writeDoctorNote}></div>
                <div className='dnf-header-text'><b>Doctor's Note</b></div>
                <div onClick={getDoctorNoteDetails} className='dnf-last-note'>View Last Note</div>
            </div>
            <div className='dnf-body'>
                <DoctorNoteInput />
            </div>
        </div>
    );
}

const mapStatetoProps = (state) => {

    const patientID = state.patientDetails.patientInfo.patientid ? state.patientDetails.patientInfo.patientid : null;
    const docID = state.login.userID;

    return {
        patientID: patientID,
        docID: docID
    };
};

export default connect(mapStatetoProps)(DoctorNoteForm);
