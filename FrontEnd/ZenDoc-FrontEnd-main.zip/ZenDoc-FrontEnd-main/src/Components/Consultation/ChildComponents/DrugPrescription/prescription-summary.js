import React, { useState, useEffect } from "react";
import { connect } from 'react-redux';

function PrescriptionSummary() {

    return (
        <>
        <div className="w-100">
        <button className="button-basics medium-button transparent-button--blue w-100">
                <i className="fas fa-plus" style={{ marginRight: '15px' }}></i>
                Add Drug </button>
        </div>
         
            <div className='pres-summary'>
                <div className='pres-summary-header label-basic'>Summary</div>
                <div className='no-summary'>
                    <div className='label-basic'>Add any drug</div>
                    <div className='label-basic'>Or</div>
                    <div className='no-summary-cst label-basic'></div>
                    <div className='label-basic'>Click CST to add prescription from last session</div>
                </div>
                <div className='summary-list'>
                    <div className='summary-list-header'>
                        <div className='label-basic'>
                            S. No
                        </div>
                        <div className='label-basic'>
                            Drug Name
                        </div>
                        <div className='label-basic'>
                            Dose
                        </div>
                        <div className='label-basic'>
                            Repeatation
                        </div>
                        <div className='label-basic'>
                            Intake
                        </div>
                        <div className='label-basic summary-icons'>
                        </div>
                        <div className='label-basic summary-icons'>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default connect(null, null)(PrescriptionSummary);
