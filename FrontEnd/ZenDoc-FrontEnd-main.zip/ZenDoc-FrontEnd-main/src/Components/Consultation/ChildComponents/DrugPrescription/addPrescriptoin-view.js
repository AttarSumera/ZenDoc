import React, { useState } from "react";
import { connect } from 'react-redux';
import TextField from '@mui/material/TextField';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';

const AddPrescription = ({ handleAddDrugClick }) => {
    const [dosage, setDosage] = useState(1);
    const [selectedTime, setSelectedTime] = useState('');
    const [intake, setIntake] = useState(''); // New state for intake

    const handleChange = (event) => {
        setDosage(event.target.value);
    }

    const handleTimeSelect = (time) => {
        setSelectedTime(time);
    };

    const handleIntakeChange = (event) => {
        setIntake(event.target.value);
    }

    return (
        <div className='add-drug'>
            <div className='search-drug'>
                <div className='search-drug-labels'>
                    <div className='label-basic'>
                        Search Drug
                    </div>
                    <span className='label-basic anchor-basic' style={{ fontSize: '12px' }}>
                        Check Drug Reaction
                    </span>
                </div>
                <div className='search-drug-input'>
                    <input className='form-control' placeholder='Type the medicine name or brand name to select' style={{ border: '1px solid #707070' }} />
                    <label className='info-label label-basic'>If not listed in the suggestion just type the drug name</label>
                </div>
            </div>

            <div className="drug-dose-container">
                <div className="left-section">
                    <label className="label-basic">Dosage (mg)</label>
                    <input className='form-control' placeholder='Dosage' style={{ border: '1px solid #707070' }} value={dosage} onChange={handleChange} />
                </div>
                <div className="right-section">
                    <label className="label-basic">Select repetition</label>
                    <div className="time-options">
                        <div
                            className={`time-option ${selectedTime === 'Morning' ? 'selected' : ''}`}
                            onClick={() => handleTimeSelect('Morning')}
                        >
                            Morning
                        </div>
                        <div
                            className={`time-option ${selectedTime === 'Noon' ? 'selected' : ''}`}
                            onClick={() => handleTimeSelect('Noon')}
                        >
                            Noon
                        </div>
                        <div
                            className={`time-option ${selectedTime === 'Evening' ? 'selected' : ''}`}
                            onClick={() => handleTimeSelect('Evening')}
                        >
                            Evening
                        </div>
                        <div
                            className={`time-option ${selectedTime === 'Night' ? 'selected' : ''}`}
                            onClick={() => handleTimeSelect('Night')}
                        >
                            Night
                        </div>
                    </div>
                </div>
            </div>

            <div className="intake-duration-container">
                <div className="left1">
                    <label className="label-basic">Intake</label>
                    <div className="MT">
                        <RadioGroup
                            aria-label="Intake"
                            name="Intake"
                            value={intake}
                            onChange={handleIntakeChange}
                            style={{ display: 'flex', flexDirection: 'row' }}
                        >
                            <FormControlLabel
                                value="0"
                                control={<Radio style={{ color: intake === "0" ? '#FF9241' : '#808080' }} />}
                                label="Empty"
                            />
                            <FormControlLabel
                                value="1"
                                control={<Radio style={{ color: intake === "1" ? '#FF9241' : '#808080' }} />}
                                label="After Food"
                            />
                        </RadioGroup>


                    </div>
                </div>
                <div className="right1">
                    <label className="label-basic">Select duration</label>
                    <div>
                        <select className="duration-dropdown">
                            <option value="1">Week</option>
                            <option value="2">2 Weeks</option>
                        </select>
                        <input type="number" className="duration-number" min="1" max="30" />
                    </div>
                </div>
            </div>

            <div className='medicine-advice'>
                <div className='medicine-advice-labels'>
                    <div className='lable basic'>
                        Medicine Advice
                    </div>
                    <div className='label-basic record-voice'>
                        Record Voice
                        <i className="fas fa-microphone" style={{ marginLeft: '5px' }}></i>
                    </div>
                </div>
                <div className='advice-text'>
                    <textarea className='form-control' placeholder='Write medicine advice for patients to follow' style={{ border: '1px solid #707070' }}></textarea>
                    <label className='info-label label-basic'>Eg. What to follow while taking the medicine and write about side effects of medicine.</label>
                </div>
                <button className="button-basics medium-button transparent-button--blue" onClick={handleAddDrugClick}>
                    <i className="fas fa-plus" style={{ marginRight: '15px' }}></i>
                    Add Drug </button>
            </div>
        </div>
    );
}

export default connect(null, null)(AddPrescription);
