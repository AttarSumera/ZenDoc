import React from 'react'

const NonPharmaSummary = () => {
    return (
        <>
            <div className="ToolDetailBTNG">
                <button className=''>Close</button>
                <button className=''>
                    <i className="fas fa-plus" style={{ marginRight: '15px' }}></i>
                    Add Task</button>
            </div>
            <div className='pres-summary'>
                <div className='pres-summary-header label-basic'>Summary</div>
                <div className='no-summary'>
                    <div className='label-basic'>Add any drug</div>
                    <div className='label-basic'>Or</div>
                    <div className='no-summary-cst label-basic'></div>
                    <div className='label-basic'>Click CST to add prescription from last session</div>
                </div>
                <div className='summary-list'>
                    <div className='summary-list-header'>
                        <div className='label-basic'>
                            S. No
                        </div>
                        <div className='label-basic'>
                            Therapy / Tool
                        </div>
                        <div className='label-basic'>
                            Duration
                        </div>
                        <div className='label-basic summary-icons'>
                        </div>
                        <div className='label-basic summary-icons'>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default NonPharmaSummary