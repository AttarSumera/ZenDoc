export const toolsList = [
    { 
        "id":1,
        "title":"Habit Tracking",
        "methods":[]
    },
    { 
        "id":2,
        "title":"Mood Tracking",
        "methods":[]
    },
    { 
        "id":3,
        "title":"Thought Journal",
        "methods":[]
    },
    { 
        "id":4,
        "title":"Anxiety/stress",
        "methods":[]
    },
    { 
        "id":5,
        "title":"OCD Manager",
        "methods":[]
    },
    { 
        "id":6,
        "title":"Phobia Companion",
        "methods":[]
    },{ 
        "id":7,
        "title":"De-addiction Tool",
        "methods":[]
    }
]