import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import _ from "lodash";

// Components Import
import PatientInfo from "./ChildComponents/patientInfo-view";
// import PsychoNote from "./ChildComponents/PsychoNote/psychoNote-view";
import Prescription from "./ChildComponents/prescription-view";
import DoctorNoteInfo from "./ChildComponents/DoctorNote/doctorNote-info";
import PsychoNoteInfo from "./ChildComponents/PsychoNote/psychoNote-Info";
import DoctorNoteForm from "./ChildComponents/DoctorNote/doctorNote-form";
import PsychoNoteForm from "./ChildComponents/PsychoNote/psychoNote-form";
import SearchPatient from "./ChildComponents/SearchNAddPatient/searchPatient-view";
import AddNewPatient from "./ChildComponents/SearchNAddPatient/addNewPatient-view";
import SearchPatientComponent from "./ChildComponents/ControlledSearchComponent/searchPatientControl";
import { Modal, Button } from "react-bootstrap";

import {
  writeDoctorNote,
  writePsychoNote,
  getPatientList,
} from "../../Actions/consultation";

import "../../style/consultation/consultation-view.css";
import "../../style/utilsCSS/common.css";
import "../../style/utilsCSS/prescription.css";
import SearchPatientInfo from "./ChildComponents/SearchNAddPatient/searchPatientInfo";

const Consultation = ({
  psychoNote,
  doctorNote,
  patientsList,
  searchText,
  addNewPatient,
  doctorNoteDetail,
  psychoNoteDetail,
  patientInfo,
  writeDoctorNote,
  writePsychoNote,
  getPatientList,
}) => {
  const [buttonsVisibility, setButtonsVisibility] = useState(false);
  const [showModalOne, setShowModalOne] = useState(false);
  const [showModalTwo, setShowModalTwo] = useState(false);
  const [showModalThree, setShowModalThree] = useState(false);
  const [searchingAndAddingPatient, setSearchingAndAddingPatient] = useState(false);

  useEffect(() => {
    // console.log('Psycho Note:', psychoNote);
    // console.log('Doctor Note:', doctorNote);
    // console.log('Doctor Note Detail:', doctorNoteDetail);
    // console.log('Patient Info:', patientInfo);
    // console.log('Searching and Adding Patient:', searchingAndAddingPatient);
    // console.log('PsychoNote Detail:', psychoNoteDetail);

    const showButtons = (!psychoNote || searchingAndAddingPatient) &&
      (!doctorNote || searchingAndAddingPatient) &&
      (!psychoNoteDetail || searchingAndAddingPatient) &&
      !doctorNoteDetail &&
      (patientInfo && patientInfo.UserId);


    setButtonsVisibility(showButtons);
  }, [psychoNote, doctorNote, doctorNoteDetail, patientInfo, searchingAndAddingPatient, psychoNoteDetail]);


  const handleWritePsychoNote = () => {
    if (patientInfo) writePsychoNote(true);
  };

  const handleWriteDoctorNote = () => {
    if (patientInfo) writeDoctorNote(true);
  };

  const handleSendNoteClick = () => {
    setShowModalOne(true);
  };

  const handleCloseModalOne = () => {
    setShowModalOne(false);
    setShowModalTwo(true);
  };

  const handleCloseModalOneCross = () => {
    setShowModalOne(false);
    setShowModalTwo(false);
    setShowModalThree(false);
  };
  const handleCloseModalTwo = () => {
    setShowModalTwo(false);
    setShowModalThree(true);
  };

  const handleCloseModalThree = () => {
    setShowModalThree(false);
  };

  const handleOpenModalThree = () => {
    setShowModalTwo(false);
    setShowModalThree(true);
  };

  return (
    <div className="consultation">
      <div className="consultation__body">
        <div className="consultation__patient-details">
          <span>Patient's details</span>
          <div className="ui input">
            <SearchPatientComponent searchText={searchText} />
          </div>
          <div className="consultation__patient-details-btn">
            <button className="consultation__patient-details-btn2">
              Cancel
            </button>
            <button
              className="consultation__patient-details-btn1"
              onClick={handleSendNoteClick}
            >
              Send Note
            </button>
          </div>
        </div>
        <div className="consultation__patient-Info">
          <PatientInfo />
        </div>

        <div className="consultation__note-pres-Parent">
          {buttonsVisibility && (
            <div className="consultation__note">
              <div className="consultation--note-Parent">
                <div className="consultation--note">
                  <button
                    onClick={handleWritePsychoNote}
                    className="BTNhandleWritePsychoNote"
                  >
                    Write Psychotherapy note
                  </button>
                </div>
                <div className="consultation--note-label1">
                  Psychiatric note includes problems, target, Goals for
                  Counselling purpose
                </div>
              </div>
              <div className="consultation--pres-Parent">
                <div className="consultation--pres">
                  <button
                    onClick={handleWriteDoctorNote}
                    className="BTNhandleWriteDoctorNote"
                  >
                    Write Doctor’s note
                  </button>
                </div>
                <div className="consultation--note-label2">
                  Doctor’s note includes patient chief complaints, Physical
                  examination, MSE, Diagnosis etc.
                </div>
              </div>
              <div className="consultation__note-pres__body"></div>
            </div>
          )}
          {/* {psychoNote && <PsychoNote />} */}
          {psychoNote && <PsychoNoteForm />}
          {psychoNoteDetail && <PsychoNoteInfo />}
          {doctorNote && <DoctorNoteForm />}
          {doctorNoteDetail && <DoctorNoteInfo />}
          <div className="consultation__prescription">
            <Prescription />
          </div>
        </div>
      </div>
      {searchText && patientsList && <SearchPatient />}
      {searchText && <SearchPatient />}
      {addNewPatient && <AddNewPatient />}

      <Modal show={showModalOne} onHide={handleCloseModalOneCross} centered
        style={{ maxWidth: '800px', width: '100%', position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title
            style={{
              textAlign: "center",
              margin: "0 auto",
              width: "100%",
              fontSize: "34px",
            }}
          >
            Are You Sure?
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="text-center">
          <div className="ModelImage"></div>
          <br />
          <p>
            By clicking Send, the final Psychotherapy note and prescription will
            be sent to the patient
            <span style={{ color: '#1E64CC' }}> #94493939300</span>
          </p>
          <hr />
          <div
            style={{ display: "flex", justifyContent: "center", gap: "10px", padding: '1rem' }}
          >
            <Button
              variant="light"
              style={{
                backgroundColor: "white",
                color: "#808080",
                border: "1px solid #808080",
                width: "150px",
                height: '50px',
              }}
              onClick={handleCloseModalOneCross}
            >
              Cancel
            </Button>
            <Button onClick={handleCloseModalOne} variant="primary"
              style={{
                backgroundColor: '#FF9241',
                color: 'white',
                width: '150px',
                height: '50px',
                border: 'none'
              }}>
              Send now
            </Button>

          </div>
        </Modal.Body>
      </Modal>

      <Modal show={showModalTwo} centered onHide={handleCloseModalOneCross}
        style={{ maxWidth: '600px', width: '100%', position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}
      >

        <Modal.Header closeButton>

        </Modal.Header>
        <Modal.Body className="text-center">
          <div className="ModelImage2"></div>
          <br />
          <h3 style={{ color: '#257D79', fontWeight: 'bold' }}>
            Sent successfully to <span style={{ color: '#1E64CC' }}>#9494949400</span>
          </h3>
          <hr />
          <div style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}>
            <Button onClick={handleOpenModalThree} variant="light" style={{ backgroundColor: '#EDF4FD', color: '#1E64CC', borderRadius: '1px', width: '150px' }}>
              Link Guardian
            </Button>
          </div>
          <p style={{ color: '#254069' }}>If patient is with guardian send invite to guardian</p>
        </Modal.Body>
      </Modal>

      <Modal show={showModalThree} onHide={handleCloseModalThree} centered
        style={{ maxWidth: '600px', width: '100%', position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}
      >
        <Modal.Header closeButton>
          <Modal.Title style={{ color: '#1E64CC', margin: '0 auto', width: '100%', textAlign: 'center', fontWeight: 'bold' }}>Enter Guardian Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="Guardian">
            <div style={{ margin: '1rem', display: 'flex', flexDirection: 'column' }}>
              <label htmlFor="guardianName" style={{ marginRight: '10px', minWidth: '100px', color: '#254069' }}>Name:</label>
              <input type="text" id="guardianName" style={{ border: '1px solid #808495' }} />
            </div>
            <div style={{ margin: '1rem', display: 'flex', flexDirection: 'column' }}>
              <label htmlFor="guardianMobile" style={{ marginRight: '10px', minWidth: '100px', color: '#254069' }}>Mobile Number:</label>
              <input type="text" id="guardianMobile" style={{ border: '1px solid #808495' }} />
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer className="d-flex justify-content-center">
          <Button variant="light" style={{ padding: '10px 70px', fontSize: '18px', border: '1px solid #808080', backgroundColor: 'transparent' }} onClick={handleCloseModalThree}>
            Close
          </Button>
          <Button variant="primary" style={{ padding: '10px 70px', fontSize: '18px' }}>
            Send
          </Button>
        </Modal.Footer>
      </Modal>


    </div>
  );
};

const mapStateToProps = (state) => ({
  psychoNote: state.patientDetails.psychoNote,
  doctorNote: state.patientDetails.doctorNote,
  patientsList: state.patientDetails.patientsList,
  searchText: state.patientDetails.searchText,
  addNewPatient: state.patientDetails.addNewPatient,
  doctorNoteDetail: state.patientDetails.doctorNoteDetail,
  psychoNoteDetail: state.patientDetails.psychoNoteDetail,
  patientInfo: state.patientDetails.patientInfo,
});

export default connect(mapStateToProps, {
  writeDoctorNote,
  writePsychoNote,
  getPatientList,
})(Consultation);
