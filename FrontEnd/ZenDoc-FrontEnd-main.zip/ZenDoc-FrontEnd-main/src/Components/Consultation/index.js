import Consultation from './consultation-view';

export default Consultation;