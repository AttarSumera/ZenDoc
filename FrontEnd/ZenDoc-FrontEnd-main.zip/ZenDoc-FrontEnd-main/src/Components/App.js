import React from 'react';
import { StrictMode } from 'react';
import ReactDOM from "react-dom";
import { applyMiddleware, createStore } from 'redux';
import thunk from 'redux-thunk';
import combineReducers from '../Reducers';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import { Provider } from 'react-redux';

/* In App Imports */
import Auth from './Authentication';
import LandingPageContainer from './landingPage';
import SignUp from './SignUp';


import AuthRouter from './Routers/AuthRouter';
import Notifications from './Notifications';
// import LeftMenu from './LeftMenu';

import '../style/consultation/patientinfo-view.css';
import ForgotPassowrdPage from './ForgotPassword/ForgotPassowrdPage';
import Onboard from './Onboard/Onboard';
import DataProvider from '../Context/DataProvider';

const App = () => {
    const store = createStore(combineReducers, applyMiddleware(thunk));
    const currentUser = {};
    console.log(store.getState());

    return (
        <Provider store={store}>
            <DataProvider> 
                <Router>
                    <div className='app-container'>
                        <Route path="/dashboard" exact component={LandingPageContainer} />

                        <Switch>
                            <Route path='/' exact component={Auth} />
                            <Route path='/signup' exact component={SignUp} />
                            <Route path='/forgot' exact component={ForgotPassowrdPage} />
                            <Route path='/onboard' exact component={Onboard} />
                        </Switch>
                    </div>
                </Router>
            </DataProvider>
        </Provider>
    );
}

export default App;
