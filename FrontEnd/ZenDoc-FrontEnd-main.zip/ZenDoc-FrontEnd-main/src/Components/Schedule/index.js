import Schedule from './schedule';

import '../../style/schedular/schedular-leftpanel.css';
import '../../style/schedular/addNewSchedule.css'

export default Schedule