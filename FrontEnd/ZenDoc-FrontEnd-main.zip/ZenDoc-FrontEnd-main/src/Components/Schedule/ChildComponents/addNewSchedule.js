import React, { useState } from "react";
import { connect } from "react-redux";
import Modal from "react-bootstrap/Modal";
import TextField from "@mui/material/TextField";
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';

import {
  addNewScheduleFlag,
  addNewScheduleMeeting,
} from "../../../Actions/schedule";

const AddNewSchedule = ({
  addNewSchedule,
  userID,
  addNewScheduleFlag,
  addNewScheduleMeeting,
}) => {
  const [state, setState] = useState({
    appointmentTitle: "",
    message: "",
    scheduleDate: new Date(),
    startTime: "09:00",
    endTime: "09:00",
    inviteeEmailId: "",
    inviteeMobileNumber: "",
  });

  const handleChange = (event) => {
    setState({
      ...state,
      [event.target.name]: event.target.value,
    });
  };

  const handleSubmit = () => {
    const obj = {
      ...state,
      userID: userID,
      patientID: "_9elmt3wt5",
    };
    addNewScheduleMeeting(obj);
  };

  const handleCancel = () => {
    addNewScheduleFlag(false);
  };

  return (
    <>
      <Modal
        dialogClassName="new-schedule-modal"
        show={addNewSchedule}
        onHide={handleCancel}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            <div className="new-schedule-header">
              <label className="label-basic">Add New Schedule</label>
            </div>
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="new-schedule-body">
            <div className="ns-title-parent">
              <label className="label-basic">Appointment Title</label>
              <input
                onChange={handleChange}
                value={state.appointmentTitle}
                name="appointmentTitle"
                type="text"
                className="form-control"
                placeholder="Add Title"
              />
            </div>

            <div className="ns-time-parent">
              <div className="ns-date-parent">
                <label className="label-basic">Date</label>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DemoContainer components={['DatePicker']}>
                    <DatePicker label="Basic date picker" />
                  </DemoContainer>
                </LocalizationProvider>
              </div>

              <div className="ns-starttime-parent">
                <label className="label-basic">Start Time</label>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DemoContainer components={['TimePicker']}>
                    <TimePicker label="Start Time" />
                  </DemoContainer>
                </LocalizationProvider>
              </div>

              <div className="ns-endtime-parent">
                <label className="label-basic">End Time</label>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DemoContainer components={['TimePicker']}>
                    <TimePicker label="End Time" />
                  </DemoContainer>
                </LocalizationProvider>
              </div>
            </div>

            <div className="ns-msg-parent">
              <label className="label-basic">Message</label>
              <textarea
                onChange={handleChange}
                value={state.message}
                name="message"
                className="form-control"
                placeholder="Write medicine advice for patients to follow"
              ></textarea>
            </div>
            <div className="ns-patient-email">
              <label className="label-basic">Enter email address</label>
              <input
                onChange={handleChange}
                value={state.inviteeEmailId}
                name="inviteeEmailId"
                type="email"
                className="form-control"
                placeholder="enter email address"
              />
            </div>
            <div className="ns-patient-number">
              <label className="label-basic">Mobile Number</label>
              <input
                onChange={handleChange}
                value={state.inviteeMobileNumber}
                name="inviteeMobileNumber"
                type="tel"
                pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}"
                className="form-control"
                placeholder="enter mobile number"
              />
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <div className="new-schedule-buttonbar">
            <button
              className="button transparent-button avg-button"
              onClick={handleCancel}
            >
              Cancel
            </button>
            <button
              className="button orange-button avg-button"
              onClick={handleSubmit}
            >
              Save Changes
            </button>
          </div>
        </Modal.Footer>
      </Modal>
    </>
  );
};

const mapStateToProps = (state) => ({
  addNewSchedule: state.schedular.addNewSchedule,
  userID: state.login.userID,
});

export default connect(mapStateToProps, {
  addNewScheduleFlag,
  addNewScheduleMeeting,
})(AddNewSchedule);
