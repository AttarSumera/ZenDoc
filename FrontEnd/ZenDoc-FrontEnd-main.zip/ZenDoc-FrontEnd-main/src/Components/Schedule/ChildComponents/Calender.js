import React from "react";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import '../../../style/schedular/calender.css'
import { DateCalendar } from '@mui/x-date-pickers/DateCalendar';

const calendar = () => {
    return (
        <>
            <div >
                <LocalizationProvider dateAdapter={AdapterDayjs} className='Sub-Cal'>
                    <DateCalendar />
                </LocalizationProvider>
            </div>
        </>

    );
};
export default calendar;
