import React, { useState, useEffect } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import '../../../style/schedular/schedular-control.css';
import '../../../style/schedular/calender.css'

const SchedularControl = ({ meetingList }) => {
    const [events, setEvents] = useState([]);

    useEffect(() => {
        const fetchedEvents = meetingList.map((meeting) => ({
            title: meeting.appointmentTitle,
            start: meeting.scheduleDate,
            end: meeting.scheduleDate + 'T' + meeting.endTime, 
            allDay: false, 
        }));
        console.log(fetchedEvents); 
        setEvents(fetchedEvents);
    }, [meetingList]);

    return (
        <div className='sc-parent'>
            <div className='sc-header'>
                Schedule Calendar
            </div>
            <div className='sc-body'>
                <FullCalendar
                    plugins={[dayGridPlugin, timeGridPlugin]}
                    initialView="dayGridMonth"
                    headerToolbar={{
                        left: 'timeGridDay,timeGridWeek,dayGridMonth',
                        center: 'title',
                        right: 'prev,next today'
                    }}
                    events={events}
                />
            </div>
        </div>
    );
};

export default SchedularControl;
