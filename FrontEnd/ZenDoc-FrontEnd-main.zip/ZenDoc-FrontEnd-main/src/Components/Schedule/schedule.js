import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import SchedularControl from './ChildComponents/schedularControl';
import SchedularLeftPanel from './ChildComponents/schedular-leftPanel';
import AddNewSchedule from './ChildComponents/addNewSchedule';
import { getScheduleDetail } from '../../Actions/schedule';

const Schedule = ({ addNewSchedule, meetingList, userID, getScheduleDetail }) => {
    useEffect(() => {
        getScheduleDetail(userID);
    }, [userID, getScheduleDetail]);

    return (
        <div className='schedular-component'>
            <SchedularLeftPanel />
            {meetingList && <SchedularControl meetingList={meetingList} />}
            {addNewSchedule && <AddNewSchedule />}
        </div>
    );
};


const mapStateToProps = (state) => ({
    addNewSchedule: state.schedular.addNewSchedule,
    meetingList: state.schedular.meetingList,
    userID: state?.login?.userID
});



export default connect(mapStateToProps, {
    getScheduleDetail
})(Schedule);
