import Authentication from './authenticationPage';

export default Authentication;