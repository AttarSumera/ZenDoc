import React, { useContext, useState } from 'react';
import { connect } from 'react-redux';
import { Link, useHistory } from 'react-router-dom';
import { login } from '../../Actions/authentication';
import GoogleIM from '../../style/images/google.svg';
import LinkedinIM from '../../style/images/linkedin.svg';
import { Datacontext } from '../../Context/DataProvider';

const SignIn = ({ login }) => {
    const [formData, setFormData] = useState({
        username: '',
        password: '',
        showPassword: false
    });

    const [errors, setErrors] = useState({
        emailError: '',
        passwordError: '',
        loginError: ''
    });

    const { setAccount, setLastname, completeProfilePercenrtage } = useContext(Datacontext);

    const history = useHistory();

    const { username, password, showPassword } = formData;

    const handleChange = (event) => {
        setFormData({
            ...formData,
            [event.target.name]: event.target.value
        });
    };

    const loginHandler = () => {
        if (validateForm()) {
            login(formData, history, setErrors, setAccount, setLastname, completeProfilePercenrtage);
            setTimeout(() => {
                setErrors({
                    ...errors
                });
            }, 3000);
        }
    }

    

    const togglePasswordVisibility = () => {
        setFormData({
            ...formData,
            showPassword: !showPassword
        });
    };

    const validateForm = () => {
        let valid = true;
        const emailOrMobileRegex = /^(?:\d{10}|\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+)$/;

        if (!username || !emailOrMobileRegex.test(username)) {
            setErrors((prevErrors) => ({
                ...prevErrors,
                emailError: 'Please enter correct credentials'
            }));
            valid = false;
        } else {
            setErrors((prevErrors) => ({
                ...prevErrors,
                emailError: ''
            }));
        }

        if (!password) {
            setErrors((prevErrors) => ({
                ...prevErrors,
                passwordError: 'Please enter your password'
            }));
            valid = false;
        } else {
            setErrors((prevErrors) => ({
                ...prevErrors,
                passwordError: ''
            }));
        }

        return valid;
    };


    return (
        <div className='sign-up-container'>
            <div className='sign-up-controls'>
                <div className='lp-parent-container-image-parent'>
                    <div className='lp-parent-container-image fas fa-head-side-virus'></div>
                    <div className='lp-parent-container-image-text'>ZenDoc</div>
                </div>
                <div className='lp-parent-container-choose'>
                    <span className='label-signin'>
                        Welcome Back! Please login to your account
                    </span>
                </div>

                <div className='lp-parent-container'>
                    <div className='ui transparent input'>
                        <input
                            name='username'
                            type='text'
                            onChange={handleChange}
                            value={username}
                            placeholder='Please Enter Your Mobile Number or Email Address'
                            onClick={() => setErrors({ ...errors, emailError: '' })}
                        />
                    </div>
                </div>
                {errors.emailError && <div className="error-message" style={{ color: 'red' }}>{errors.emailError}</div>}

                <div className='lp-parent-container'>
                    <div className='ui transparent input d-flex align-items-center'>
                        <input
                            name='password'
                            onChange={handleChange}
                            value={password}
                            type={showPassword ? 'text' : 'password'}
                            placeholder='Password'
                            onClick={() => setErrors({ ...errors, passwordError: '', loginError: '' })}
                        />
                        <span>
                            <i
                                className={`eye-icon fas ${showPassword ? 'fa-eye ' : 'fa-eye-slash'}`}
                                onClick={togglePasswordVisibility}
                            ></i>
                        </span>
                    </div>
                </div>
                {errors.passwordError && <div className="error-message" style={{ color: 'red' }}>{errors.passwordError}</div>}
                {errors.loginError && <div className="error-message" style={{ color: 'red' }}>{errors.loginError}</div>}

                <div className='lp-remPass-container'>
                    <div className='ui transparent'>
                        <input id='remember' type='checkbox' />
                        <label className='label-basic gray-label' htmlFor='remember' style={{ marginTop: '12px' }}>
                            Remember Me
                        </label>
                    </div>
                    <Link to='forgot'>
                        <label className='label-basic gray-label' style={{ marginTop: '12px' }}>
                            Forgot Password?
                        </label>
                    </Link>
                </div>
                <div className='lp-parent-container-signup'>
                    <div className='no-border'>
                        <input onClick={loginHandler} className='login-button' type='button' value='Login' />
                        <Link to='/signup'>
                            <input className='signup-button' type='button' value='Sign Up' />
                        </Link>
                    </div>
                </div>

                {/* <div className='lp-parent-container'>
                    <label className='label-basic gray-label-medium no-margin'>Or</label>
                </div>
                <div className='lp-signup-container'>
                    <div className='gray-border zq-full-width flex-display'>
                        <label className='label-basic gray-label no-margin' style={{ fontSize: '16px' }}>
                            Sign Up with google
                        </label>
                        <img src={GoogleIM} alt='Google Logo' style={{ marginLeft: '8px' }} />
                    </div>                     <div className='gray-border zq-full-width flex-display'>
                        <label className='label-basic gray-label no-margin'>Sign Up with LinkedIn</label>
                        <img src={LinkedinIM} alt='Linkedin Logo' style={{ marginLeft: '8px' }} />
                    </div>
                </div> */}
            </div>
        </div>
    );
};



export default connect(null, { login })(SignIn);

