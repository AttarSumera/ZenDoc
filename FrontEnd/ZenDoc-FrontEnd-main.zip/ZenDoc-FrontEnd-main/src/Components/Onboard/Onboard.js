import React, { useContext, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import Header from '../header';
import { getCity, getCountry, getDistrict, getState, submitProfile } from '../../Services/authentication.service';
import { useHistory } from 'react-router-dom';
import '../../style/Onboard/Onboard.css'
import { Datacontext } from '../../Context/DataProvider';
import { connect } from 'react-redux';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import { Modal, Button } from "react-bootstrap";

const Onboard = ({ docDetails }) => {
    const [showModalThree, setShowModalThree] = useState(false);


    const [formData, setFormData] = useState({
        linkedIn: '',
        firstName: '',
        lastName: '',
        contact: '',
        preferredName: '',
        address: '',
        pinCode: '',
        state: '',
        Country: '',
        District: '',
        city: '',
        education: '',
        specialities: '',
        workExperience: '',
        medicalID: '',
        photoID: '',
        userId: '',
        salutation: ''
    });

    const [storeCountry, setStoredCountry] = useState()
    const [storeState, setStoredState] = useState()
    const [storeDistrict, setStoredDistrict] = useState()
    const [storeCity, setStoredCity] = useState()

    const { linkedIn, firstName, lastName, contact, address, pinCode, state, education, specialities, workExperience, medicalID, photoID, userId, Country, District, city, salutation } = formData;

    const history = useHistory();

    const { completeProfilePercenrtage, setCompleteProfilePercenrtage } = useContext(Datacontext)
    console.log(completeProfilePercenrtage)

    const handleInputChange = async (e) => {
        const { name, value } = e.target;
        let parsedValue = value;

        if (name === 'city' || name === 'state') {
            parsedValue = parseInt(value);
        }

        setFormData((prevData) => ({
            ...prevData,
            [name]: parsedValue
        }));
    };

    const handleCloseModalThree = () => {
        setShowModalThree(false);
    };

    const handleOpenModalThree = () => {
        setShowModalThree(true);
    };

    const handleAddGuardianClick = () => {
        handleOpenModalThree();
    };



    const handleSubmit = async (e) => {
        e.preventDefault();
        const success = await submitProfile(formData, setCompleteProfilePercenrtage);
        if (success) {
            history.push('/dashboard');
        } else {

        }
    };

    const handleCountryDetail = async (e) => {
        e.preventDefault();
        await getCountry(setStoredCountry)
    }

    const handleStateDetail = async (e) => {
        e.preventDefault();
        await getState(storeCountry, setStoredState)
    }

    const handleDistrictDetail = async (e) => {
        e.preventDefault();
        await getDistrict(storeState, setStoredDistrict, formData)
    }

    const handleCityDetail = async (e) => {
        e.preventDefault();
        await getCity(storeDistrict, setStoredCity, formData)
    }


    const [selectedFile, setSelectedFile] = useState(null);
    const fileInputRef = useRef(null);

    const handleFileInputChange = (event) => {
        setSelectedFile(event.target.files[0]);
    };

    const handleUploadClick = () => {
        fileInputRef.current.click();
    };
    return (
        <>

            <div className="containero">
                <Header />
                <form onSubmit={handleSubmit}>
                    <div className="container-fluid mt-3">
                        <div className="row justify-content-center">
                            <div className="col-lg-6 custom-container d-flex justify-content-between OnboardProfile">
                                <h2>Complete your profile</h2>
                                <div className=''>
                                    <Link to="/dashboard" className='Skip'>Skip</Link>
                                    <button type="submit" className='Onboard-BTN' onClick={handleSubmit}>Complete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="container-fluid">
                        <div className="row justify-content-center">
                            <div className="col-md-6">
                                <div className="form-group Li-Box">
                                    <label htmlFor="inputAddress">Link your LinkedIn profile</label>
                                    <input type="url" className="form-control" id="linkedIn" name="linkedIn" value={linkedIn} placeholder="Ex: www.linkedin.com/advik29393" onChange={handleInputChange} required />
                                </div>
                                <div className=' M-Box'>

                                    <div className="form-row">
                                        <div className="form-group col-md-6">
                                            <label htmlFor="firstName">First Name</label>
                                            <input type="text" className="form-control" id="firstName" placeholder="Enter First name" name="firstName" value={docDetails.firstName} onChange={handleInputChange} required readOnly />
                                        </div>
                                        <div className="form-group col-md-6">
                                            <label htmlFor="lastName">Last Name</label>
                                            <input type="text" className="form-control" id="lastName" placeholder="Enter last name" value={docDetails.lastName} onChange={handleInputChange} required readOnly={docDetails.lastName != "" ? true : false} />
                                        </div>
                                    </div>
                                    <div className="form-row mt-3">
                                        <div className="form-group col-md-6">
                                            <label htmlFor="contact">Contact</label>
                                            <input type="text" className="form-control" id="contact" placeholder="+91 937847484949" name="contact" value={docDetails.phoneNumber} onChange={handleInputChange} required readOnly />
                                        </div>


                                        <div className="form-group col-md-6">
                                            <label htmlFor="firstName">Preffered Name</label>
                                            <div className="d-flex align-items-baseline">
                                                <div>
                                                    <select
                                                        id="salutation"
                                                        value={docDetails.salutation}
                                                        className="form-control"
                                                        name="salutation"
                                                        onChange={handleInputChange}
                                                        style={{ width: 'auto' }}
                                                    >
                                                        <option value={1}>Dr</option>
                                                        <option value={2}>Mr</option>
                                                        <option value={3}>Miss</option>
                                                    </select>
                                                </div>
                                                <div className="lp-parent-container-onboard">
                                                    <div className="ui transparent input">
                                                        <input
                                                            onChange={handleInputChange}
                                                            name="preferredName"
                                                            value={docDetails.prefferedName}
                                                            type="text"
                                                            placeholder="Enter Your Preferred Name Here"
                                                            readOnly
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div className="form-row mt-3">
                                        <div className="form-group col-md-6" onClick={handleCountryDetail}>
                                            <label htmlFor="Country">Country</label>
                                            <select id="Country" value={Country} className="form-control" name="Country" onChange={(e) => handleInputChange(e)}>
                                                {storeCountry && storeCountry.map((c) => (
                                                    <option value={c.id} key={c.id}>{c.countryName}</option>
                                                ))}
                                            </select>
                                        </div>


                                        <div className="form-group col-md-6" onClick={handleStateDetail}>
                                            <label htmlFor="state">State</label>
                                            <select id="state" value={state} className="form-control" name="state" onChange={(e) => handleInputChange(e)}>
                                                {storeState && storeState.map((s) => (
                                                    <option value={s.id} key={s.id}>{s.stateName}</option>
                                                ))}
                                            </select>
                                        </div>

                                        <div className="form-group col-md-6" onClick={handleDistrictDetail}>
                                            <label htmlFor="District">District</label>
                                            <select id="District" value={District} className="form-control" name="District" onChange={(e) => handleInputChange(e)}>
                                                {storeDistrict && storeDistrict.map((d) => (
                                                    <option value={d.id} key={d.id}>{d.distName}</option>
                                                ))}
                                            </select>
                                        </div>

                                        <div className="form-group col-md-6" onClick={handleCityDetail}>
                                            <label htmlFor="state">City</label>
                                            <select id="City" value={city} className="form-control" name="city" onChange={(e) => handleInputChange(e)}>
                                                {storeCity && storeCity.map((city) => (
                                                    <option value={city.id} key={city.id}>{city.cityName}</option>
                                                ))}
                                            </select>
                                        </div>


                                    </div>

                                    <div className="form-row mt-3">
                                        <div className="form-group col-md-9">
                                            <label htmlFor="address">Address Line 1</label>
                                            <input type="text" className="form-control" id="address" placeholder="Enter your location" name="address" value={address} onChange={handleInputChange} required />
                                        </div>
                                    </div>
                                    <div className="form-row mt-1">
                                        <div className="form-group col-md-5">
                                            <label htmlFor="pinCode">Pin Code</label>
                                            <input type="text" className="form-control" id="pinCode" placeholder="Enter Your Zip Code" name="pinCode" value={pinCode} onChange={handleInputChange} required />
                                        </div>
                                    </div>


                                    <div className="form-group">
                                        <label htmlFor="specialities">Specialities</label>
                                        <textarea className="form-control" id="specialities" rows="3" placeholder="Enter Your Specialities" name="specialities" onChange={handleInputChange} required value={specialities}></textarea>
                                    </div>
                                    <div className="form-row mt-3">
                                        <div className="form-group col-md-5">
                                            <label htmlFor="workExperience">Work Experience</label>
                                            <select id="workExperience" className="form-control" name="workExperience" onChange={handleInputChange} value={workExperience}>
                                                <option value="0-1 year">0-1 year</option>
                                                <option>...</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
               
                                <div className="L-Box mt-3">
                                    <div className="form-row mt-3">
                                        <div className="form-group col-md-6 d-flex" >
                                            <label htmlFor="education">Education</label>
                                            {/* <input type="text" className="form-control" id="education" placeholder="Enter your course name" name="education" onChange={handleInputChange} value={education} /> */}
                                            <AddOutlinedIcon onClick={handleAddGuardianClick} style={{ marginLeft: '.5rem' }} />

                                            <Modal show={showModalThree} onHide={handleCloseModalThree} centered>
                                                <Modal.Header closeButton>
                                                    <Modal.Title style={{ color: '#254069', margin: '0 auto', width: '100%', fontWeight: 'bold' }}>Add education</Modal.Title>
                                                </Modal.Header>
                                                <Modal.Body>
                                                    <div >
                                                        <div style={{ margin: '1rem', display: 'flex', flexDirection: 'column' }}>
                                                            <label htmlFor="guardianName" style={{ marginRight: '10px', minWidth: '100px', color: '#254069' }}>School/College</label>
                                                            <input type="text" id="guardianName" style={{ border: '1px solid #808495' }} />
                                                        </div>
                                                    </div>

                                                    <div className="Doc-Degree">
                                                        <div className="form-group col-md-6">
                                                            <label htmlFor="state">Degree of Doctor</label>
                                                            <select id="state" value={state} className="form-control" name="state" onChange={handleInputChange} >
                                                                <option value="">Undergraduate</option>
                                                                <option value="">Postgraduate</option>
                                                            </select>
                                                        </div>
                                                        <div className="form-group col-md-6 Doc-Degree-IP">
                                                            <input type="file" />
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <div style={{ margin: '1rem', display: 'flex', flexDirection: 'column' }}>
                                                            <label htmlFor="guardianMobile" style={{ marginRight: '10px', minWidth: '100px', color: '#254069' }}>Field Of Study</label>
                                                            <input type="text" id="guardianMobile" style={{ border: '1px solid #808495' }} />
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <div style={{ margin: '1rem', display: 'flex', flexDirection: 'column' }}>
                                                            <label htmlFor="guardianMobile" style={{ marginRight: '10px', minWidth: '100px', color: '#254069' }}>Grade</label>
                                                            <input type="text" id="guardianMobile" style={{ border: '1px solid #808495' }} />
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <div style={{ margin: '1rem', display: 'flex', flexDirection: 'column' }}>
                                                            <label htmlFor="guardianMobile" style={{ marginRight: '10px', minWidth: '100px', color: '#254069' }}>Description</label>
                                                            <input type="text" id="guardianMobile" style={{ border: '1px solid #808495' }} />
                                                        </div>
                                                    </div>
                                                </Modal.Body>
                                                <Modal.Footer className="d-flex justify-content-center">
                                                    <Button variant="light" style={{ padding: '10px 70px', fontSize: '18px', border: '1px solid #808080', backgroundColor: 'transparent' }} onClick={handleCloseModalThree}>
                                                        Close
                                                    </Button>
                                                    <Button variant="primary" style={{ padding: '10px 70px', fontSize: '18px' }}>
                                                        Save
                                                    </Button>
                                                </Modal.Footer>
                                            </Modal>

                                        </div>

                                    </div>
                                    <div className='edu-data'>
                                        <input type="text" className="form-control" id="education" placeholder="Enter your course name" name="education" onChange={handleInputChange} value={education} />
                                    </div>
                                    {/* <div className="form-row Doc-Degree">
                                        <div className="form-group col-md-6">
                                            <label htmlFor="state">Degree of Doctor</label>
                                            <select id="state" value={state} className="form-control" name="state" onChange={handleInputChange} >
                                                <option value="">Undergraduate</option>
                                                <option value="">Postgraduate</option>
                                            </select>
                                        </div>
                                        <div className="form-group col-md-6 Doc-Degree-IP">
                                            <input type="file" />
                                        </div>
                                    </div> */}

                                </div>

                                <div className="L-Box mt-3">

                                    <div className="form-row">
                                        <div className="form-group col-md-6">
                                            <label htmlFor="medicalID">REG Number</label>
                                            <input type="text" className="form-control" id="medicalID" name="medicalID" onChange={handleInputChange} required placeholder="312456875463244632525" value={medicalID} />
                                        </div>


                                        {/* <div className="form-row"> */}
                                        <div className="form-group col-md-6">
                                            <label htmlFor="photoID">Photo ID</label>
                                            <div className="input-group">

                                                <input type="text" className="form-control" id="photoID" value={selectedFile ? selectedFile.name : ''} readOnly />


                                                <input ref={fileInputRef} type="file" className="form-control" id="photoID" style={{ display: 'none' }} onChange={handleFileInputChange} />


                                                <label htmlFor="photoID" className="input-group-text" style={{ backgroundColor: 'transparent', color: '#808495', cursor: 'pointer' }} onClick={handleUploadClick}>
                                                    <i className="fas fa-upload"></i>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    {/* </div> */}
                                </div>
                            </div>
                        </div>
                    </div>
                </form >
            </div >
        </>
    )
}

const mapStatetoProps = (state) => {
    return {
        docDetails: state.login.doctorDetails
    };
};

export default connect(mapStatetoProps)(Onboard);
