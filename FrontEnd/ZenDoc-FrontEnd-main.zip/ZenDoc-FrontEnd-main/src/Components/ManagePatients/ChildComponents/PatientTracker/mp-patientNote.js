import React from "react";
import { connect } from "react-redux";
import SelectedDoctorNote from "../SelectedDoctorNote/mp-doctorNote";
import DoctorPrescription from "../SelectedDoctorNote/mp-prescription";
import { setSelectedNoteID } from "../../../../Actions/managePatient";

const PatientNoteBody = ({
  doctorNote,
  drugs,
  tools,
  selectedNoteID,
  setSelectedNoteID,
}) => {
  const showDoctorNote = () => {
    setSelectedNoteID(
      selectedNoteID === doctorNote.docNoteID ? null : doctorNote.docNoteID
    );
  };

  return (
    <>
      <div className="mp-ph-note-item">
        <div className="mp-ph-note-summary">
          <div className="mp-nh-session">{doctorNote.docNoteID}</div>
          <div className="mp-nh-date">{doctorNote.Date}</div>
          <div className="mp-nh-patient">Patient Name/Guardian</div>
          <div className="mp-nh-doctor">Doctor Name</div>
          <div className="mp-nh-visit">Reason to Visit</div>
          <div className="mp-nh-icon">
            <i onClick={showDoctorNote} className="fas fa-chevron-right"></i>
          </div>
        </div>
      </div>
      {doctorNote.docNoteID === selectedNoteID && (
        <div className="np-ph-note-detail">
          <SelectedDoctorNote doctorNoteDetail={doctorNote} />
          {(drugs?.length > 0 || tools?.length > 0) && (
            <DoctorPrescription drugs={drugs} tools={tools} />
          )}
        </div>
      )}
    </>
  );
};

const mapStateToProps = (state) => {
  return {
    selectedNoteID: state.managePatient.selectedNoteID,
  };
};

export default connect(mapStateToProps, { setSelectedNoteID })(PatientNoteBody);
