import React from "react";
import { connect } from 'react-redux';

import PatientInfoCard from './mp-patientCard.js';
import PatientHistory from "./mp-patientHitstory.js";
import PatientNavBar from "./mp-patientNavbar.js";
import '../../../../style/managePatients/mp-patientInfo.css';

import '../../../../style/managePatients/mp-patientHistory.css';

const PatientDetails = ({ patientInfo, patientHistory }) => {
    return (
        <div className='mp-patient-detail'>
            <div className='mp-patient-detail-header'>
                <div className='mp-patient-detail-back fas fa-arrow-left'></div>
                <div className='mp-pd-buttons'>
                    <button className='medium-button transparent-button--bluemp'>CST</button>
                    <button className='medium-button blue-button'>Start Consulting</button>
                </div>
            </div>
            <PatientInfoCard patientInfo={patientInfo} />
            <PatientNavBar />
            <PatientHistory patientHistory={patientHistory} /> 
        </div>
    );
}

const mapStateToProps = (state) => {
    return {
        patientInfo: state.managePatient.patientInfo,
        patientHistory: state.managePatient.patientHistory
    };
}

export default connect(mapStateToProps)(PatientDetails);
