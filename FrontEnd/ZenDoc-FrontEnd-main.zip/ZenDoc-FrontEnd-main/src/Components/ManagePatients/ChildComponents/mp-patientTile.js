import React from 'react';
import { connect } from 'react-redux';
import { getPatientHistory } from '../../../Actions/managePatient';

const PatientTile = ({ userId, patientInfo, getPatientHistory }) => {
    const userName = `${patientInfo.firstName} ${patientInfo.middleName} ${patientInfo.lastName}`;
    const country = patientInfo.country || "United States";
    const phoneNumber = patientInfo.phoneNumber || "987654321";

    const handleGetPatientHistory = () => {
        getPatientHistory({
            userID: userId,
            patID: patientInfo.UserId,
            pageNum: 1
        }, patientInfo);
    };

    return (
        <div className='mp-patient-tile'>
            <div className='mp-tile-data' tabIndex="1" onClick={handleGetPatientHistory}>
                <div className='mp-user-img fas fa-user-tie'></div>
                <div className='mp-user-data'>
                    <label className='label-basic mp-user'>{userName}</label>
                    <label className='label-basic mp-country'>{country}</label>
                    <label className='label-basic mp-mobile'>{phoneNumber}</label>
                </div>
                <div className='mp-tile-icon far fa-calendar'></div>
            </div>
            <div className='mp-tile-empty'></div>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        userId: state?.login?.user?.userID
    };
};

export default connect(mapStateToProps, { getPatientHistory })(PatientTile);
