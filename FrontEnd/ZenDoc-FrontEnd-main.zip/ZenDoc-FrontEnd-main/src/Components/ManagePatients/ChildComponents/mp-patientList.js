import React from "react";
import PatientTile from "./mp-patientTile";

const PatientList = ({ patientList }) => {
  const getPatientList = (list) => {
    return list.map((info) => {
      return <PatientTile key={info.UserId} patientInfo={info} />;
    });
  };

  const patientListItems = getPatientList(patientList);

  return (
    <div className='mp-patient-tiles-page'>
      <div className="landing-Page__search">
        <div className="landing-Page__search-bar">
          <button type="submit">
            {/* <i className="fas fa-search"></i> */}
            Search Patients
          </button>
          {/* <div className="Landing_Page_Left">
            Search Patients
          </div> */}
          <input
            type="text"
            placeholder="Enter patient ID or mobile number to search patient"
          />
          <button type="submit">
            <i className="fas fa-search"></i>
            Search
          </button>
        </div>
        <button className="landing-Page__add-patient">
          <i className="fas fa-plus"></i>
          Add New Patient
        </button>
      </div>
      <div className='mp-patient-tile-parent'>
        {patientListItems}
      </div>
    </div>
  );
}

export default PatientList;
