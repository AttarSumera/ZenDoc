import ManagePatients from "./managePatient";
export default ManagePatients;