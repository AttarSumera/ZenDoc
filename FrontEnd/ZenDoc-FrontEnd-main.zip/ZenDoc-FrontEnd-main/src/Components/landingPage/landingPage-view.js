import React from "react";
import Header from "../header";
import Tiles from "./childComponents";
import { tilesCollection } from "./tilesJson";
import "../../style/landingPage/landingPage.css";

const LandingPage = ({ tileClickHandler }) => {
  const getTilesCollection = (tilesCollection) => {
    return tilesCollection.map((tile) => (
      <div className="tile-Container" key={tile.id}>
        <Tiles tile={tile} tileClickHandler={tileClickHandler} />
      </div>
    ));
  };

  return (
    <div className="landing-Page">
      <Header />
      <div className="landing-Page__search">
        <div className="landing-Page__search-bar">
        <button type="submit">
            {/* <i className="fas fa-search"></i> */}
            Search Patients
          </button>
          {/* <div className="Landing_Page_Left">
            Search Patients
          </div> */}
          <input
            type="text"
            placeholder="Enter patient ID or mobile number to search patient"
          />
          <button type="submit">
            <i className="fas fa-search"></i>
            Search
          </button>
        </div>
        <button className="landing-Page__add-patient">
          <i className="fas fa-plus"></i>
          Add New Patient
        </button>
      </div>


      <div className="tiles-container">
        {getTilesCollection(tilesCollection)}
      </div>
    </div>
  );
};

export default LandingPage;
