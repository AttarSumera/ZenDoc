import LandingPageContainer from './landingpage-container';

export default LandingPageContainer;