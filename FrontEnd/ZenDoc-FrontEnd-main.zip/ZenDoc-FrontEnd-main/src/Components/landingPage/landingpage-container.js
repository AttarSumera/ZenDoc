import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import LandingPage from './landingPage-view';
import LeftMenu from '../leftMenu';
import LoadComponentPage from './childComponents/loadComponent';
import Header from '../header';
import { setActiveTab } from '../../Actions/landingPage';

const LandingPageContainer = () => {
    const activetab = useSelector(state => state.activetab);
    const dispatch = useDispatch();

    const setActiveTabHandler = (event) => {
        const activeTab = event.target.getAttribute('name');
        dispatch(setActiveTab(activeTab));
    };

    return (
        <>
            {activetab === "" ? (
                <LandingPage tileClickHandler={setActiveTabHandler} />
            ) : (
                <div className='component-container'>
                    <div className='component-header'>
                        <Header />
                    </div>
                    <div className='component-body'>
                        <LeftMenu menuItemClickHandler={setActiveTabHandler}/>
                        <div className= 'component-page-container'>
                            <LoadComponentPage activeTab={activetab} />
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};

export default LandingPageContainer;