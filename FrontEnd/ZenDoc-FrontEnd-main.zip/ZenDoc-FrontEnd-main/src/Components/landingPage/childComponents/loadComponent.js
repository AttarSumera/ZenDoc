import React from "react";

import Consultation from '../../Consultation';
import Schedule from "../../Schedule";
import ManagePatients from "../../ManagePatients";
import Notification from '../../Notifications';
import DrugTool from "../../Tools/DrugTool";
import Blog from "../../Blog/Blog";
import Setting from "../../Settings/index";

const LoadComponentPage = (props) => {

    let component;

    switch (props.activeTab) {
        case "1":
            return <Consultation />
            break;
        case "2":
            return <Schedule />;
            break;
        case "3":
            return <ManagePatients />;
            break;
        case "4":
            return <Notification />;
            break;
        case "5":
            return <DrugTool />
            break;
        case "6":
            return <Blog />;
            break;
        case "7":
            return <Setting />;
            break;
        default:
            return <div></div>
            break;
    }
}

export default LoadComponentPage;