import Tiles from './tiles';

export default Tiles;