import React, { useState } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { createDoctor } from "../../Actions/authentication";
import { useHistory } from "react-router-dom";

const SignUp = ({ createDoctor }) => {
    const [formData, setFormData] = useState({
        firstName: "",
        lastName: "",
        emailAddress: "",
        userPassword: "",
        mobileNumber: "",
        confirmPassword: "",
        prefferedName: "",
        salutation: "",
        agreement: false,
        showPassword: false,
        showConfirmPassword: false,
    });

    const [errors, setErrors] = useState({
        firstNameError: "",
        lastNameError: "",
        emailAddressError: "",
        mobileNumberError: "",
        passwordError: "",
        confirmPasswordError: "",
        agreementError: "",
        signupError: ""
    });

    const {
        firstName,
        lastName,
        prefferedName,
        emailAddress,
        userPassword,
        confirmPassword,
        agreement,
        showPassword,
        showConfirmPassword,
        mobileNumber,
        salutation
    } = formData;

    const history = useHistory();

    const signupHandler = () => {
        if (validateForm()) {
            createDoctor(
                {
                    firstName,
                    lastName,
                    prefferedName,
                    emailAddress,
                    userPassword,
                    mobileNumber,
                    confirmPassword,
                    salutation,
                },
                history,
                setErrors
            );
            setTimeout(() => {
                setErrors({
                    ...errors
                });
            }, 3000);
        }
    };

    const handleChange = (event) => {
        const { name, value } = event.target;
        setErrors((prevErrors) => ({
            ...prevErrors,
            [`${name}Error`]: "",
        }));
        setFormData((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };


    const handleCheckboxChange = () => {
        setFormData((prevState) => ({
            ...prevState,
            agreement: !prevState.agreement,
        }));
    };

    const togglePasswordVisibility = () => {
        setFormData((prevState) => ({
            ...prevState,
            showPassword: !prevState.showPassword,
        }));
    };

    const toggleConfirmPasswordVisibility = () => {
        setFormData((prevState) => ({
            ...prevState,
            showConfirmPassword: !prevState.showConfirmPassword,
        }));
    };

    const validateForm = () => {
        let valid = true;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!firstName) {
            setErrors((prevErrors) => ({
                ...prevErrors,
                firstNameError: "Please enter your first name",
            }));
            valid = false;
        }

        if (!lastName) {
            setErrors((prevErrors) => ({
                ...prevErrors,
                lastNameError: "Please enter your last name",
            }));
            valid = false;
        }

        if (!prefferedName) {
            setErrors((prevErrors) => ({
                ...prevErrors,
                preferredNameError: "Please enter your preferred Name",
            }));
            valid = false;
        }

        if (!emailAddress || !emailRegex.test(emailAddress)) {
            setErrors((prevErrors) => ({
                ...prevErrors,
                emailAddressError: "Please enter a valid email address",
            }));
            valid = false;
        }

        if (!mobileNumber) {
            setErrors((prevErrors) => ({
                ...prevErrors,
                mobileNumberError: "Please enter your mobile number",
            }));
            valid = false;
        }

        if (!userPassword) {
            setErrors((prevErrors) => ({
                ...prevErrors,
                passwordError: "Please enter your password",
            }));
            valid = false;
        }

        if (!confirmPassword || confirmPassword !== userPassword) {
            setErrors((prevErrors) => ({
                ...prevErrors,
                confirmPasswordError: "Passwords do not match",
            }));
            valid = false;
        }

        if (!agreement) {
            setErrors((prevErrors) => ({
                ...prevErrors,
                agreementError: "Please agree to the terms and conditions",
            }));
            valid = false;
        }

        return valid;
    };


    return (
        <div className="sign-up-container">
            <div className="sign-up-controls">
                <div className="lp-parent-container-image-parent">
                    <div className="lp-parent-container-image"></div>
                    <div className="lp-parent-container-image-text">ZenDoc</div>
                </div>
                <div className="lp-parent-container-choose">
                    <span className="label-signin">
                        Please complete to create your account
                    </span>
                </div>

                <div className="d-flex align-items-baseline">
                    <div>
                        <select
                            id="salutation"
                            value={salutation}
                            className="form-control"
                            name="salutation"
                            onChange={handleChange}
                            style={{ width: 'auto' }}
                        >
                            <option value={0}></option>
                            <option value={1}>Dr</option>
                            <option value={2}>Mr</option>
                            <option value={3}>Mrs</option>
                        </select>

                    </div>
                    <div className="lp-parent-container">
                        <div className="ui transparent input">
                            <input
                                onChange={handleChange}
                                onClick={() => setErrors({ ...errors, preferredNameError: '' })}
                                name="prefferedName"
                                value={prefferedName}
                                type="text"
                                placeholder="Enter Your Preferred Name Here"
                            />
                        </div>
                    </div>
                </div>
                {errors.preferredNameError && (
                    <div className="error-message">{errors.preferredNameError}</div>
                )}

                <div className="lp-parent-container">
                    <div className="ui transparent input d-flex align-items-center">
                        <input
                            onChange={handleChange}
                            onClick={() => setErrors({ ...errors, firstNameError: '' })}
                            name="firstName"
                            value={firstName}
                            placeholder="First Name"
                        />

                    </div>
                </div>

                {errors.firstNameError && (
                    <div className="error-message">{errors.firstNameError}</div>
                )}

                <div className="lp-parent-container">
                    <div className="ui transparent input d-flex align-items-center">
                        <input
                            onChange={handleChange}
                            onClick={() => setErrors({ ...errors, lastNameError: '' })}
                            name="lastName"
                            value={lastName}

                            placeholder="Last Name"
                        />

                    </div>
                </div>

                {errors.lastNameError && (
                    <div className="error-message">{errors.lastNameError}</div>
                )}


                <div className="lp-parent-container">
                    <div className="ui transparent input">
                        <input
                            onChange={handleChange}
                            onClick={() => setErrors({ ...errors, emailAddressError: '' })}
                            name="emailAddress"
                            value={emailAddress}
                            type="email"
                            placeholder="Email"
                        />
                    </div>
                </div>
                {errors.emailAddressError && (
                    <div className="error-message">{errors.emailAddressError}</div>
                )}
                <div className="lp-parent-container">
                    <div className="ui transparent input">
                        <input
                            onChange={handleChange}

                            name="mobileNumber"
                            value={mobileNumber}
                            type="number"
                            placeholder="Mobile Number"
                            onClick={() => setErrors({ ...errors, mobileNumberError: '' })}
                        />
                    </div>
                </div>
                {errors.mobileNumberError && (
                    <div className="error-message">{errors.mobileNumberError}</div>
                )}
                <div className="lp-parent-container">
                    <div className="ui transparent input d-flex align-items-center">
                        <input
                            onChange={handleChange}
                            onClick={() => setErrors({ ...errors, passwordError: '' })}
                            name="userPassword"
                            value={userPassword}
                            type={showPassword ? "text" : "password"}
                            placeholder="Password"

                        />
                        <span>
                            <i
                                className={`eye-icon fas ${showPassword ? "fa-eye" : "fa-eye-slash"
                                    }`}
                                onClick={togglePasswordVisibility}
                            ></i>
                        </span>
                    </div>
                </div>
                {errors.passwordError && (
                    <div className="error-message">{errors.passwordError}</div>
                )}
                <div className="lp-parent-container">
                    <div className="ui transparent input d-flex align-items-center">
                        <input
                            onChange={handleChange}
                            onClick={() => setErrors({ ...errors, confirmPasswordError: '' })}
                            name="confirmPassword"
                            value={confirmPassword}
                            type={showConfirmPassword ? "text" : "password"}
                            placeholder="Confirm Password"
                        />
                        <span>
                            <i
                                className={`eye-icon fas ${showConfirmPassword ? "fa-eye" : "fa-eye-slash"
                                    }`}
                                onClick={toggleConfirmPasswordVisibility}
                            ></i>
                        </span>
                    </div>
                </div>
                {errors.confirmPasswordError && (
                    <div className="error-message">{errors.confirmPasswordError}</div>
                )}
                <div
                    className="lp-parent-container-terms d-flex"
                    style={{ gap: "12px" }}
                >
                    <input
                        name="agreement"
                        checked={agreement}
                        id="signupCheck"
                        type="checkbox"
                        onChange={handleCheckboxChange}
                        onClick={() => setErrors({ ...errors, agreementError: '' })}
                    />
                    <label
                        htmlFor="signupCheck"
                        style={{ marginTop: "12px" }}
                        className="label-basic gray-label"
                    >
                        {" "}
                        I agree with all terms and conditions{" "}
                    </label>
                </div>
                {errors.agreementError && (
                    <div className="error-message">{errors.agreementError}</div>
                )}
                   {errors.signupError && (
                    <div className="error-message">{errors.signupError}</div>
                )}
                <div className="lp-parent-container-signup">
                    <div className="no-border-center">
                        <input
                            onClick={signupHandler}
                            className="avg-button no-border-btn btn--border-radius pa-btn ui button mini btn--padding-lr"
                            type="button"
                            value="Sign up"
                        />
                    </div>
                    <div className="link-to-login-parent">
                        <Link to="/">
                            <span className="link-to-login">
                                {" "}
                                Already have an account? Sign in
                            </span>
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default connect(null, { createDoctor })(SignUp);