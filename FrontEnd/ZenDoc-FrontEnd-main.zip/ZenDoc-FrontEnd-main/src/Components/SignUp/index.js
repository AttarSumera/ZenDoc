import SignUp from './SignUpPage';
export default SignUp;