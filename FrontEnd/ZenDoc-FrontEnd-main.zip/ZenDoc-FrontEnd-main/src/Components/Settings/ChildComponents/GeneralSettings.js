import React from 'react'
import Save from '../../../style/images/Save.svg'
import Reset from '../../../style/images/Reset.svg'
import '../../../style/Settings/GeneralSetting.css'
import GeneralSettingForm from './GeneralSettingFrom'
import GeneralSettingAccounts from './GeneralSettingAccounts'

const GeneralSettingsComponent = () => {
  return (
    <>
      <div className="GeneralSettingContainer">
        <div className="GeneralSetting">

          <div className='GeneralHeadingContainer'>
            <h5 className="GeneralSettingHead"><b>Accounts details</b></h5>
          </div>

          <div className='GeneralSettingBTNContainer'>
            <button>
              <img src={Reset} alt="Reset-BTN-IMG" className='GeneralSettingBTNContainerimg'/>
              Reset
            </button>
            <button>
              <img src={Save} alt="Save-BTN-IMG" className='GeneralSettingBTNContainerimg'/>
              Save
            </button>
          </div>
        </div>
        <hr />
        <GeneralSettingForm />
        <GeneralSettingAccounts/>
      </div>

    </>
  )
};

export default GeneralSettingsComponent