import React, { useState } from 'react';
import ProfileIMG from '../../../style/images/profile-mid.svg';
import DegreeIcon from '../../../style/images/Degree.svg';
import ExperienceIcon from '../../../style/images/Experience.svg';
import '../../../style/Settings/Profile.css';
import EditIcon from '../../../style/images/Edit.svg';
import Education from './Education';
import Experience from './Experience';
import Specialized from './Specialized';
import EditContainer from './ProfileEditContainer'; // Import EditContainer

const ProfileComponent = () => {
  const [isEditing, setIsEditing] = useState(false); // State to track if editing mode is active

  const handleEditClick = () => {
    setIsEditing(true); // Set editing mode to true when Edit button is clicked
  };

  // Conditional rendering based on whether editing mode is active
  if (isEditing) {
    return <EditContainer />;
  } else {
    return (
      <>
        <div className="profile-Container">
          <div className='Edit-Container' onClick={handleEditClick}>
            <img src={EditIcon} alt="" />
            <h5>Edit</h5>
          </div>
          <div className="Profie-Sub-Container">

            <div className="ProfileIMG">
              <img src={ProfileIMG} alt="" />
            </div>

            <h5>Dr.Ashokan varma</h5>

            <div className='Profie-Sub-Container2'>

              <div className='Sub-Profile'>
                <img src={DegreeIcon} alt="" />
                <h6>
                  MBBS, M.D. (Psychiatry)
                </h6>
              </div>

              <div className='Sub-Profile'>
                <img src={ExperienceIcon} alt="" />
                <h6>
                  29 Years Experience
                </h6>
              </div>

            </div>

          </div>

        </div>
        <div className='Profile-Description'>
          <h5>Bio</h5>
          <p>Prof. Dr. Ennapadam S Krishnamoorthy (ESK) MBBS, MD, DCN (Lond), Ph.D. (Lond), FRCP (Lond, Edin & Glas), MAMS (India), FIMSA, FIPS. Internationally recognized, he has special interests and experience in epilepsy, dementia, autism, more..</p>
        </div>

        <Education />
        <Experience />
        <Specialized />
      </>
    );
  }
}

export default ProfileComponent;
