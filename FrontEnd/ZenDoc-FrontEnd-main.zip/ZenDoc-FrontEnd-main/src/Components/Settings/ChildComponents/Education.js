import React from 'react'
import EducationGroup from '../../../style/images/EducationGroup.svg'

const Education = () => {
    return (
        <>
            <div className="EducationContainer">
                <div>
                    <img src={EducationGroup} alt="" />
                </div>
                <div className='EducationContainerSub2'>
                    <h6>  <b>Education</b></h6>
                    <ul>
                        <li >MBBS - Kasturba Medical College - 1991</li>
                        <li>M.D. (Psychiatry) - Manipal Academy Of Higher Education, Manipal, India - 1995</li>
                    </ul>
                    <button>+ Add New</button>
                </div>
            </div>
        </>
    )
}

export default Education