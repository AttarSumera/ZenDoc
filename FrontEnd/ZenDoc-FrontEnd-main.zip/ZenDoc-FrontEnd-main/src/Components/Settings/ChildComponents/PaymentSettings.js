import React from 'react'

const PaymentSettingsComponent = () => {
    return <div>Payment Settings Component</div>;
  };

  export default PaymentSettingsComponent