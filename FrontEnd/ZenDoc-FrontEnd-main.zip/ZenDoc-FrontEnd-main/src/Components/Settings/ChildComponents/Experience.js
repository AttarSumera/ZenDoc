import React from 'react'
import ExperienceIcon from '../../../style/images/ExperienceIcon.svg'

const Experience = () => {
    return (
        <>
            <div className="ExperienceContainer">
                <div>
                    <img src={ExperienceIcon} alt="" />
                </div>
                <div className='ExperienceContainerSub2'>
                    <h6>  <b>Experience</b></h6>
                    <ul>
                        <li >2000 - 2001 Assistant Director- Research at National Neuroscience Institute</li>
                        <li>2002 - 2013 Director- Neurological Sciences & Rehabilitation at TS Srinivasan Centre & The Institute of Neurological Sciences, VHS</li>
                        <li>2009 - 2020 Founder & Managing Director at Dr. ESK’s CIMS Pvt. Ltd.</li>
                        <li>2009 - 2020 Founder & Managing Director at Dr. ESK’s CIMS Pvt. Ltd.</li>
                        <li>2015 - 2020 President Elect at International Neuropsychiatry Association</li>
                    </ul>
                    <button>+ Add New</button>
                </div>
            </div>
        </>
    )
}

export default Experience