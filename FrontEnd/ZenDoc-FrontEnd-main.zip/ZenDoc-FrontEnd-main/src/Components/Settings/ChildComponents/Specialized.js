import React from 'react'
import SpecializedIcon from '../../../style/images/Spec.svg'

const Specialized = () => {
    return (
        <>
            <div className="SpecializedContainer">
                <div>
                    <img src={SpecializedIcon} alt="" />
                </div>
                <div className='SpecializedContainerSub2'>
                    <h6>  <b>Specialized</b></h6>
                    <ul>
                        <li >HC Bajoria Oration - Indian Epilepsy Association - 2008</li>
                        <li>UN Mehta Oration - NEUCON- Controversies in Neurology - 2009</li>
                        <li>Madras Psychological Society Endowment Lectures. - Madras Psychological Society, Department of Psychology, Madras University - 2011</li>
                        <li>President’s Medal - Royal College of Psychiatrists, UK - 2011</li>
                    </ul>
                    <button>+ Add New</button>
                </div>
            </div>
        </>
    )
}

export default Specialized