import React from 'react'
import Setting from './settings'

const index = () => {
    return (
        <Setting />
    )
}

export default index