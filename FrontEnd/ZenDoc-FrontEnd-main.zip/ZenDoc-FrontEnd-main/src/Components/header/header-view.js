import React, { useContext, useState } from 'react';
import ReactDOM from 'react-dom';
import '../../style/landingPage/header.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBell, faAngleDown, faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import { useHistory } from 'react-router-dom';
import { Logout } from '../../Actions/authentication';
import { Datacontext } from '../../Context/DataProvider';
import { connect } from 'react-redux';

function Header({ docDetails }) {
    const [dropdownOpen, setDropdownOpen] = useState(false);

    const { lastname, account, setAccount, setLastname, Salutation, setSalutation } = useContext(Datacontext);

    const toggleDropdown = () => {
        setDropdownOpen(!dropdownOpen);
    };

    const history = useHistory();

    const handleLogout = () => {
        Logout(history);
        localStorage.removeItem('account');
        localStorage.removeItem('lastname');
        setAccount("");
        setLastname("");
    };

    const salutationOptions = [
        { value: 1, name: 'Dr' },
        { value: 2, name: 'Mr' },
        { value: 3, name: 'Mrs' },
    ];

    const selectedSalutation = salutationOptions?.find(option => option?.value === docDetails?.salutation);

    return (
        <div className='header'>
            <div className='header__image fas fa-head-side-virus'></div>
            <div className='header__text'>ZenDoc</div>
            <div className='header__icons'>
                {/* <div className='header__user-icon'>AV</div> */}
                <div className='header__user-name' onClick={toggleDropdown}>
                    <a href="#" className='header__user-name_a'>{selectedSalutation?.name}. {docDetails?.prefferedName} </a>
                    <span style={{ marginLeft: '8px', color: '#0e58c7' }}>
                        <FontAwesomeIcon icon={faAngleDown} />
                    </span>
                    {dropdownOpen && (
                        <div className="dropdown-content">
                            <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                <span style={{ color: '#0e58c7', transform: 'rotate(180deg)' }}>
                                    <FontAwesomeIcon icon={faSignOutAlt} />
                                </span>
                                <button onClick={handleLogout}>Logout</button>
                            </span>
                        </div>
                    )}
                </div>
                <div className='header__notification-icon'>
                    <FontAwesomeIcon icon={faBell} />
                </div>
            </div>
        </div>
    );
}

// export default Header;

const mapStatetoProps = (state) => {
    const docDetails = state.login && state.login.doctorDetails;
    return {
        docDetails: docDetails ? docDetails : null
    };
};


export default connect(mapStatetoProps)(Header);