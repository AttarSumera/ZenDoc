import Header from './header-view';

export default Header;