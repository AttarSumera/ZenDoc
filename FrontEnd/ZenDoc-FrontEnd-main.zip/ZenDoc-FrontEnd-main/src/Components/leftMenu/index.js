import LeftMenu from "./leftMenu-view";

export default LeftMenu;