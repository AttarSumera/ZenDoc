import React from 'react';
import '../../style/landingPage/leftMenu.css';

const LeftMenu = ({ menuItemClickHandler }) => {
    const handleMenuItemClick = (event) => {
        menuItemClickHandler(event);
    }

    const tags = {
        home: '',
        schedule: '2',
        patients: '3',
        notification: '4',
        Tools: '5',
        blog: '6',
        settings: '7',
        help: 'help' 
    };

    return (
        <div className='left-menu'>
            <div className='left-menu-icon-container'>
                {Object.keys(tags).map((key) => (
                    <div
                        key={key}
                        onClick={handleMenuItemClick}
                        className={`left-menu__item left-menu__item--${key}`}
                        name={tags[key]}
                    >
                        <div name={tags[key]} className='left-menu-item-text'>{key.charAt(0).toUpperCase() + key.slice(1)}</div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default LeftMenu;
