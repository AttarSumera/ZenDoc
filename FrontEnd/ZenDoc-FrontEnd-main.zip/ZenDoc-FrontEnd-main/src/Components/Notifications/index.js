import Notifications from "./patientCard";

export default Notifications;