import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Button, Card, Modal } from "react-bootstrap";
import { connect } from "react-redux";
import "../../style/dashBoard/patientCard.css";
import {
  loadData,
  filterByDate,
  filterByFutureDate,
} from "../../Actions/notifications";
import { data } from "./data";
import RotateRightIcon from "@mui/icons-material/RotateRight";
import VideocamOutlinedIcon from "@mui/icons-material/VideocamOutlined";
import DashboardImg from "../../style/images/Icon material-dashboard.svg";
import ListImg from "../../style/images/Icon awesome-list.svg";
import ListCard from "./ListCard";
import GridCard from "./GridCard";

const PatientCard = ({
  userID,
  appointmentDetail,
  filteredAppointments,
  loadData,
  filterByDate,
  filterByFutureDate,
}) => {
  const [show, setShow] = useState(false);
  const [filteredData, setFilteredData] = useState(data);
  const [heading, setHeading] = useState("Appointments");
  const [listView, setListView] = useState(false);
  const [activeButton, setActiveButton] = useState(""); // State variable to track active button

  useEffect(() => {
    loadData({
      userID: "_bl3gg3ejp",
    });
  }, [userID, loadData]);

  const handleShow = () => setShow(true);
  const handleClose = () => setShow(false);

  const handleFilter = (value) => {
    let newHeading = "Appointments";
    const today = new Date().toISOString().slice(0, 10);

    if (value === "today") {
      const filteredToday = data.filter((item) => item.date === today);
      setFilteredData(filteredToday);
      newHeading = "Notification Center - Today";
    } else if (value === "not-today") {
      const filteredFuture = data.filter((item) => item.date > today);
      setFilteredData(filteredFuture);
      newHeading = "Notification Center - Upcoming";
    } else if (value === "") {
      const filteredMissed = data.filter((item) => item.date < today);
      setFilteredData(filteredMissed);
      newHeading = "Notification Center - Missed";
    } else if (value === "Pending") {
      const filteredPending = data.filter((item) => item.date < today);
      setFilteredData(filteredPending);
      newHeading = "Notification Center - Pending";
    } else {
      setFilteredData(data);
    }
    setHeading(newHeading);
    setActiveButton(value);
  };

  const handleDashboardClick = () => {
    setListView(false);
  };

  const handleListClick = () => {
    setListView(true);
  };

  return (
    <div className="Card_container">
      <div className="heading_box">
        <h4>{heading}</h4>
      </div>
      <div className="Patient-Card-Main-Container">
        <div className="Paitent_filter">
          <Button
            value="today"
            variant="basic"
            className={`button-notification ${activeButton === "today" ? "active" : ""
              }`}
            style={{
              color: activeButton === "today" ? "white" : "#1E64CC",
              backgroundColor: activeButton === "today" ? "#1E64CC" : "white",
            }}
            onClick={() => handleFilter("today")}
          >
            Todays
          </Button>
          <Button
            value="not-today"
            variant="basic"
            className={`button-notification ${activeButton === "not-today" ? "active" : ""
              }`}
            style={{
              color: activeButton === "not-today" ? "white" : "#1E64CC",
              backgroundColor:
                activeButton === "not-today" ? "#1E64CC" : "white",
            }}
            onClick={() => handleFilter("not-today")}
          >
            Upcoming
          </Button>
          <Button
            value=""
            variant="basic"
            className={`button-notification ${activeButton === "" ? "active" : ""
              }`}
            style={{
              color: activeButton === "" ? "white" : "#1E64CC",
              backgroundColor: activeButton === "" ? "#1E64CC" : "white",
            }}
            onClick={() => handleFilter("")}
          >
            Missed
          </Button>
          <Button
            value="Pending"
            variant="basic"
            className={`button-notification ${activeButton === "Pending" ? "active" : ""
              }`}
            style={{
              color: activeButton === "Pending" ? "white" : "#1E64CC",
              backgroundColor: activeButton === "Pending" ? "#1E64CC" : "white",
            }}
            onClick={() => handleFilter("Pending")}
          >
            Pending request
          </Button>
        </div>
        <div className="Patient-Card-Sub-Container2">
          <a href="">Clear All</a>
          <div>
            <img src={DashboardImg} onClick={handleDashboardClick} alt="" />
          </div>
          <div onClick={handleListClick}>
            <img src={ListImg} alt="" />
          </div>
        </div>
      </div>

      {listView ? (
        <div className="list-view">
          {filteredData.map((details, index) => (
            <div key={index}>
              <ListCard details={details} />
            </div>
          ))}
        </div>
      ) : (
        <div className="card-view">
          <div className="container-div">
            {filteredData.map((details, index) => (
              <GridCard
                details={details}
                key={index}
                handleGridCardClick={() => handleGridCardClick(details)}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    userID: state?.login?.userID,
    appointmentDetail: state.appointmentDetail.appointmentDetail,
    filteredAppointments: state.appointmentDetail.filteredAppointments,
  };
};

export default connect(mapStateToProps, {
  loadData,
  filterByDate,
  filterByFutureDate,
})(PatientCard);

{
  /* <Modal
  className="ad-scheduled-details"
  show={show}
  onHide={handleClose}
>
  <Modal.Header closeButton>
    <Modal.Title className="contained-modal-title-vcenter ad-heading">
      Appointment Details
    </Modal.Title>
    <Button className="close" onClick={handleClose}>
      <span aria-hidden="true">&times;</span>
    </Button>
  </Modal.Header>

  <Modal.Body>
    <div>
      <Card>
        <Card.Body>
          <div className="d-flex flex-row">
            <div className="d-flex flex-column">
              <Card.Img
                className="ad-patient-img"
                src={details.imgUrl}
              />
              <Card.Text className="ad-patient-phone">
                {details.contact}
              </Card.Text>
              <Card.Text className="ad-patient-email">
                itsmeexample@gmail.com
              </Card.Text>
              <Card.Text className="ad-patient-consulting-mode">
                Virtual Consulting
              </Card.Text>
              <Card.Text className="ad-patient-status">
                Active
              </Card.Text>
            </div>
            <div className="d-flex flex-column">
              {/* Additional details */
}
//             </div>
//           </div>
//         </Card.Body>
//       </Card>
//     </div>
//   </Modal.Body>
//   <Modal.Footer>
//     <Button
//       className="ad-button-basic"
//       variant="secondary"
//       onClick={handleClose}
//     >
//       Close
//     </Button>
//     <Button
//       className="ad-button-primary"
//       variant="primary"
//       onClick={handleClose}
//     >
//       Save Changes
//     </Button>
//   </Modal.Footer>
// </Modal> */}
