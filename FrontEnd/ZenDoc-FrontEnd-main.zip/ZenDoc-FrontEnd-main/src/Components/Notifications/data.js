export const data = [
  {
    "id": 1,
    "name": "John Doe",
    "date": "2024-03-11",
    "time": "10:00 AM",
    "contact": "123-456-7890",
    "priority": "High",
    "imgUrl": ""
  },
  {
    "id": 2,
    "name": "Jane Smith",
    "date": "2024-03-14",
    "time": "11:00 AM",
    "contact": "456-789-0123",
    "priority": "Medium",
    "imgUrl": "",
    "sideEffects":"Side effects reported"
  },
  {
    "id": 3,
    "name": "Alice Johnson",
    "date": "2024-03-13",
    "time": "12:00 PM",
    "contact": "789-012-3456",
    "priority": "Low",
    "imgUrl": ""
  },
  {
    "id": 4,
    "name": "Alice Johnson",
    "date": "2024-03-18",
    "time": "12:00 PM",
    "contact": "789-012-3456",
    "priority": "Low",
    "imgUrl": ""
  }
]