import React, { useState } from "react";
import { Card, Button } from "react-bootstrap";
import RotateRightIcon from "@mui/icons-material/RotateRight";
import VideocamOutlinedIcon from "@mui/icons-material/VideocamOutlined";
import AppointmentDetails from "./childComponents/AppointmentDetails";
import profile from "../../style/images/profile-mid.svg";


const GridCard = ({ details, handleShow, handleClose }) => {
  const [showModalOne, setShowModalOne] = useState(false);
  const [showModalTwo, setShowModalTwo] = useState(false);

  const handleSendNoteClick = () => {
    setShowModalOne(true);
  };

  return (
    <>
      <Card className="patient-card">
        <Card.Body>
          <div className="d-flex flex-row">
            <div className="d-flex flex-column">
              <Card.Img className="patient-img" src={profile} />
              <Card.Text onClick={handleSendNoteClick} className="details-link">
                View Details
              </Card.Text>
            </div>
            <div className="d-flex flex-column">
              <Card.Text className="patient-name">{details.name}</Card.Text>
              <Card.Text className="patient-phone">{details.contact}</Card.Text>
              <Card.Text className="alloted-time">
                <span style={{ color: "#257D79", marginRight: "0.1rem" }}>
                  <VideocamOutlinedIcon fontSize="16px" />
                </span>
                {details.date} {details.time}
              </Card.Text>
              <Card.Text className="patient-priority">
                <span style={{ marginRight: ".4rem" }}>&#9679;</span>
                {details.priority}
              </Card.Text>
              {details.sideEffects && (
                <Card.Text className="patient-priority-side-effects">
                  <span style={{ marginRight: ".2rem" }}>&#9650;</span>
                  {details.sideEffects}
                </Card.Text>
              )}
            </div>
          </div>
        </Card.Body>
        <Card.Footer style={{ backgroundColor: "white", display: "flex" }}>
          <Button
            variant="primary"
            className="button-primary"
            onClick={handleClose}
          >
            Attend Now
          </Button>
          <Button variant="basic" className="button-basic">
            <RotateRightIcon fontSize="20px" />
            Reschedule
          </Button>
        </Card.Footer>
      </Card>

      <AppointmentDetails
        setShowModalOne={setShowModalOne}
        showModalOne={showModalOne}
        details={details}
      />
    </>
  );
};

export default GridCard;
