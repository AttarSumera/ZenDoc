import React from 'react'

const SearchDrug = () => {
    return (
        <>

            <div className="Search_Drug_Main_Container">

                <h6 className="search-drug-heading">Search Drug</h6>

                <div className="search-drug-content">
                    <div className="search-drug-contentsearch-bar">
                        <input type="text" placeholder="Enter Drug name" />
                        <button type="submit" className='search-drug-submit-button' >
                            <span className='search-drug-span'></span>
                            <span style={{ marginRight: '5px' }}>+</span> Add
                        </button>
                    </div>
                    <button className="search-drug-add-patient">Check</button>
                </div>

                <div className='search-bar-button-container'>
                    <button className='First-Drug'># drug 1</button>
                    <button className='Second-Drug'># drug 2</button>
                </div>
                <h4 className='search-drug-heading-h4'>Select to view side effect for each drug</h4>

            </div>
        </>
    )
}

export default SearchDrug