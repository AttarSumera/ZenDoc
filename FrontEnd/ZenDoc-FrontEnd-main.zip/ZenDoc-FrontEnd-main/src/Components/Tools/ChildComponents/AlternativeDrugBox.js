import React from 'react'
import PillImg from '../../../style/images/Icon awesome-pills.svg'

function Box() {
    return (
        <>
            <div className='Alternative-Drug-Box-Container'>
                <div className="Alternative-Drug-Box">
                    <div>
                        <img src={PillImg} alt="Pills Icon" />
                    </div>
                    <div>
                        <p>Abatacept 10 <br /> <span className='Alternative-Drug-Span' style={{ fontWeight: 'lighter' }}>Dosage 500mg</span></p>
                    </div>

                </div>
                <button className='Alternative-Drug-Button'><span style={{ marginRight: '5px' }}>+</span>Add</button>
            </div>

        </>
    );
}
export default Box;