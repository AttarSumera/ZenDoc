import React from 'react'
import '../../../style/Tools/SideEffect.css'

const SideEffect = () => {
    return (
        <div className='Side-Effects-Main-Container'>
            <div className="Search_Drug_Main_Container">
                <div className="Side-Effects">
                    <h5 className="Side-Effect-H5">Side effects</h5>
                    <div className='Common-Side-Effects'>
                        <h6 className='Side-Effect-H6'>Common Side effects</h6>
                        <p className='Side-Effect-P'>The core symptom of depression is said
                            to be anhedonia, which refers to loss of interest or a loss of
                            feeling of pleasure in certain activities that usually bring joy to</p>
                    </div>
                    <div className='Rare-Side-Effects'>
                        <h6 className="Side-Effect-H6">Rare side effects:</h6>
                        <p className='Side-Effect-P'>Depressed mood is a symptom of some
                            mood disorders such as major depressive
                            disorder or dysthymia; it is a normal temporary reaction to life events, such as the
                            loss of a loved one; and it is also a symptom of some physical diseases and a side effect of some
                            drugs.</p>
                    </div>

                    <h6 className="Side-Effect-H6">Age / Dosage limit</h6>
                    <div className='Age-Dose-Limit-Main mt-3'>
                        <div className='Age-Dose-Limit-1'>
                            <p>Age</p>
                            <p>18-30</p>
                        </div>
                        <div className='Age-Dose-Limit-2'>
                            <p>Dosage Limit</p>
                            <p>500mg</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    )
}

export default SideEffect