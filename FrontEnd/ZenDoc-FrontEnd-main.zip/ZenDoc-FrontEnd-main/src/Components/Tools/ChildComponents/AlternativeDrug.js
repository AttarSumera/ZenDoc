import React from 'react'
import Box from './AlternativeDrugBox'
import '../../../style/Tools/AlternativeDrug.css'

const AlternativeDrug = () => {
    return (
        <div className='Search_AlternativeDrug_Container'>
            <div className='Search_AlternativeDrug_SubContainer'>
                <h5 className="Side-Effect-H5">Alternative Drug</h5>

                <div className='Box-Container'>
                    <div><Box /></div>
                    <div><Box /></div>
                </div>

            </div>
        </div>
    )
}

export default AlternativeDrug