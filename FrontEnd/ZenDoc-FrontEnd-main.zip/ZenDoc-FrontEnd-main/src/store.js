const store = {};

export default store;